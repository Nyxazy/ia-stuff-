class SeasonReset:
    def __init__(self, server):
        self.server = server
        self.auto_reset = True

    def start(self):
        try:
            from threading import Thread
            def loop():
                import time
                while True:
                   
                    time.sleep(24 * 3600)// reset süresi bu
                    if self.auto_reset:
                        self.reset_season()

            Thread(target=loop, daemon=True).start()
        except Exception as e:
            print('[SeasonReset] start error:', e)

    def reset_season(self):
      
        try:
            import sqlite3
            with sqlite3.connect('database/Player/plr.db') as conn:
                c = conn.cursor()
                
                c.execute('UPDATE plrs SET freepass=0, buypass=0')
                conn.commit()
            return True
        except Exception as e:
            print('[SeasonReset] Error:', e)
            return False
