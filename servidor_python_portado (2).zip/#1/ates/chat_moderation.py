import re
import time
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JSON_DIR = ROOT / "JSON"
JSON_DIR.mkdir(exist_ok=True)
MUTE_FILE = JSON_DIR / "club_mutes.json"
BADWORDS_FILE = JSON_DIR / "chat_badwords.json"


DEFAULT_BADWORDS = ["siktir","orospu","amk","piç","bok","anan","aq","mk"]

AD_PATTERNS = [r"https?://", r"www\.", r"\.com\b", r"\.net\b", r"\.org\b", r"t\.me/", r"telegram\.me", r"discord\.gg", r"@\w+"]


DEFAULT_MUTE_SECONDS_FOR_AD = 10 * 60  # reklam tespitinde varsayılan susturma süresi (saniye)
DEFAULT_MUTE_SECONDS_FOR_PROFANITY = 10 * 60  # küfür tespitinde varsayılan susturma süresi (saniye)
STRIKES_FILE = JSON_DIR / "club_strikes.json"
BANS_FILE = JSON_DIR / "club_bans.json"
STRIKE_LIMIT = 5


def _load_json(path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        pass
    return default


def _save_json(path, data):
    try:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception:
        pass


def _ensure_files():
    if not BADWORDS_FILE.exists():
        _save_json(BADWORDS_FILE, DEFAULT_BADWORDS)
    if not MUTE_FILE.exists():
        _save_json(MUTE_FILE, {"clubs": {}})
    if not STRIKES_FILE.exists():
        _save_json(STRIKES_FILE, {"clubs": {}})
    if not BANS_FILE.exists():
        _save_json(BANS_FILE, {"clubs": {}})


def load_badwords():
    _ensure_files()
    return _load_json(BADWORDS_FILE, DEFAULT_BADWORDS)


def is_ad(text: str) -> bool:
    if not text:
        return False
    for p in AD_PATTERNS:
        if re.search(p, text, re.IGNORECASE):
            return True
    return False


def contains_profanity(text: str) -> bool:
    words = load_badwords()
    t = text.lower()
    for w in words:
        if not w:
            continue
        if w in t:
            return True
    return False


def _load_mutes():
    _ensure_files()
    return _load_json(MUTE_FILE, {"clubs": {}})


def _save_mutes(data):
    _save_json(MUTE_FILE, data)


def _load_strikes():
    _ensure_files()
    return _load_json(STRIKES_FILE, {"clubs": {}})


def _save_strikes(data):
    _save_json(STRIKES_FILE, data)


def _load_bans():
    _ensure_files()
    return _load_json(BANS_FILE, {"clubs": {}})


def _save_bans(data):
    _save_json(BANS_FILE, data)


def add_strike(target_lowid: int, club_id: int) -> int:
    """Increase strike count for player in club and return new strikes count."""
    data = _load_strikes()
    clubs = data.setdefault('clubs', {})
    c = clubs.setdefault(str(club_id), {})
    cur = int(c.get(str(target_lowid), 0))
    cur += 1
    c[str(target_lowid)] = cur
    data['clubs'][str(club_id)] = c
    _save_strikes(data)
    return cur


def reset_strikes(target_lowid: int, club_id: int):
    data = _load_strikes()
    clubs = data.setdefault('clubs', {})
    c = clubs.setdefault(str(club_id), {})
    if str(target_lowid) in c:
        c.pop(str(target_lowid), None)
        data['clubs'][str(club_id)] = c
        _save_strikes(data)


def ban_player(target_lowid: int, club_id: int, reason: str = 'auto') -> bool:
    data = _load_bans()
    clubs = data.setdefault('clubs', {})
    c = clubs.setdefault(str(club_id), {})
    c[str(target_lowid)] = {"banned_at": int(time.time()), "reason": reason}
    data['clubs'][str(club_id)] = c
    _save_bans(data)
    # Optionally reset strikes and mutes
    reset_strikes(target_lowid, club_id)
    m = _load_mutes()
    mc = m.get('clubs', {})
    club_m = mc.get(str(club_id), {})
    if str(target_lowid) in club_m:
        club_m.pop(str(target_lowid), None)
        m['clubs'][str(club_id)] = club_m
        _save_mutes(m)
    return True


def is_banned(target_lowid: int, club_id: int) -> bool:
    data = _load_bans()
    clubs = data.get('clubs', {})
    c = clubs.get(str(club_id), {})
    return str(target_lowid) in c


def send_inbox_notification(account_code, message: str, kind: int = 81) -> bool:
    try:
        from Logic.Notifications import add_notification_lowid
        kwargs = {}
        if isinstance(kind, int) and kind >= 29000000:
            kwargs['SkinID'] = int(kind - 29000000)
        elif isinstance(kind, int) and kind >= 16000000:
            kwargs['BrawlerID'] = int(kind - 16000000)
        add_notification_lowid(account_code, str(message), kind=kind, **kwargs)
        return True
    except Exception:
        return False


def add_notification_to_player_obj(player_obj, message: str, kind: int = 81):
    try:
        lowid = getattr(player_obj, 'low_id', None)
        if lowid is None:
            return False
        return send_inbox_notification(lowid, message, kind)
    except Exception:
        return False


def is_muted(lowid: int, club_id: int) -> (bool, int):
    """Return (muted_bool, seconds_remaining)"""
    data = _load_mutes()
    clubs = data.get('clubs', {})
    c = clubs.get(str(club_id), {})
    entry = c.get(str(lowid))
    if not entry:
        return False, 0
    until = int(entry.get('mute_until', 0))
    now = int(time.time())
    if until <= now:
        
        c.pop(str(lowid), None)
        data['clubs'][str(club_id)] = c
        _save_mutes(data)
        return False, 0
    return True, until - now


def mute_player(target_lowid: int, club_id: int, seconds: int, reason: str = "admin") -> bool:
    data = _load_mutes()
    clubs = data.setdefault('clubs', {})
    c = clubs.setdefault(str(club_id), {})
    until = int(time.time()) + max(0, int(seconds))
    c[str(target_lowid)] = {"mute_until": until, "reason": reason}
    data['clubs'][str(club_id)] = c
    _save_mutes(data)
    return True


def unmute_player(target_lowid: int, club_id: int) -> bool:
    data = _load_mutes()
    clubs = data.setdefault('clubs', {})
    c = clubs.setdefault(str(club_id), {})
    if str(target_lowid) in c:
        c.pop(str(target_lowid), None)
        data['clubs'][str(club_id)] = c
        _save_mutes(data)
        return True
    return False


def can_send(sender_lowid: int, club_id: int, text: str) -> (bool, str):
    """Return (allowed: bool, reason: str). Reasons: 'ok','muted','ad','profanity'"""
 
    # Ban check
    if is_banned(sender_lowid, club_id):
        return False, 'banned'

    muted, rem = is_muted(sender_lowid, club_id)
    if muted:
        return False, f"muted:{rem}"

    if is_ad(text):
        return False, 'ad'
   
    if contains_profanity(text):
        return False, 'profanity'
    return True, 'ok'


def auto_handle_violation(sender_lowid: int, club_id: int, reason: str):
    """Otomatik ihlal işleyicisi: reklam veya küfür tespitinde süreli mute uygular ve bot mesajını döndürür."""
    try:
        # Add strike
        strikes = add_strike(sender_lowid, club_id)
        if strikes >= STRIKE_LIMIT:
            ban_player(sender_lowid, club_id, reason=f'auto-{reason}-strike')
            # send inbox notification
            try:
                send_inbox_notification(sender_lowid, f"Kuralları {STRIKE_LIMIT} kez ihlal ettiğiniz için kulüpten yasaklandınız.", kind=81)
            except Exception:
                pass
            return True, f"Kuralları {STRIKE_LIMIT} kez ihlal ettiğiniz için kulüpten yasaklandınız."

        if reason == 'ad':
            secs = DEFAULT_MUTE_SECONDS_FOR_AD
            mute_player(sender_lowid, club_id, secs, reason='auto-ad')
            left = STRIKE_LIMIT - strikes
            # send inbox notification
            try:
                send_inbox_notification(sender_lowid, f"Mesajınız reklam içerdiği için {secs} saniye susturuldunuz. Kalan hak: {left}.", kind=81)
            except Exception:
                pass
            return True, f"Mesajınız reklam içerdiği için {secs} saniye susturuldunuz. Kalan hak: {left}."
        if reason == 'profanity':
            secs = DEFAULT_MUTE_SECONDS_FOR_PROFANITY
            mute_player(sender_lowid, club_id, secs, reason='auto-profanity')
            left = STRIKE_LIMIT - strikes
            try:
                send_inbox_notification(sender_lowid, f"Uygunsuz dil kullandığınız için {secs} saniye susturuldunuz. Kalan hak: {left}.", kind=81)
            except Exception:
                pass
            return True, f"Uygunsuz dil kullandığınız için {secs} saniye susturuldunuz. Kalan hak: {left}."
    except Exception:
        pass
    return False, ''
