
class Store:
    def __init__(self, server):
        self.server = server
        self.catalog = []

    def start(self):
        pass

    def refresh_catalog(self):
      
        self.catalog = []
