
import time

class AntiDDoS:
    def __init__(self, server):
        self.server = server
        self.enabled = True
        self.conn_counts = {}

    def start(self):
        pass

    def check_connection(self, ip):
        if not self.enabled:
            return False
        cnt = self.conn_counts.get(ip, 0)
        return cnt > 100

    def record_connection(self, ip):
        self.conn_counts[ip] = self.conn_counts.get(ip, 0) + 1

    def reset_counts(self):
        self.conn_counts.clear()
