class ServerAdmin:
    def __init__(self, server):
        self.server = server

    def start(self):
        pass

    def broadcast(self, message):
        # broadcast a message to all connected players (stub)
        return True

    def grant_resources(self, lowID: int, gold: int = 0, gems: int = 0, starpoints: int = 0):
        """Grant resources to a player identified by lowID. Returns True on success."""
        try:
            import sqlite3, time
            db_path = 'database/Player/plr.db'
            with sqlite3.connect(db_path) as conn:
                c = conn.cursor()
                c.execute('SELECT lowID, gold, gems, starpoints FROM plrs WHERE lowID = ?', (lowID,))
                row = c.fetchone()
                if not row:
                    return False

                cur_gold = row[1] or 0
                cur_gems = row[2] or 0
                cur_star = row[3] or 0

                new_gold = cur_gold + int(gold)
                new_gems = cur_gems + int(gems)
                new_star = cur_star + int(starpoints)

                c.execute('UPDATE plrs SET gold = ?, gems = ?, starpoints = ? WHERE lowID = ?', (new_gold, new_gems, new_star, lowID))
                conn.commit()

            # send notification if notifications module available
            try:
                from Logic.Notifications import add_notification_lowid
                parts = []
                if gold:
                    parts.append(f'{gold} gold')
                if gems:
                    parts.append(f'{gems} gems')
                if starpoints:
                    parts.append(f'{starpoints} star points')
                add_notification_lowid(lowID, 'You received ' + ', '.join(parts), kind=81)
            except Exception:
                pass

            return True
        except Exception:
            return False
