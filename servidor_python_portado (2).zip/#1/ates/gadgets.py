class GadgetsManager:
    def __init__(self, server):
        self.server = server

    def start(self):
        pass

    def equip_gadget(self, player, gadget_id):
        player.gadget = gadget_id
        return True
