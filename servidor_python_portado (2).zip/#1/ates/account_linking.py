class AccountLinker:
    def __init__(self, server):
        self.server = server
        self.links = {}
        self._file = 'database/account_links.json'
        self._load()

    def start(self):
        pass

    def link_account(self, player_id, external_id):
        self.links[str(player_id)] = external_id
        self._save()
        return True

    def get_link(self, player_id):
        return self.links.get(str(player_id))

    def _load(self):
        try:
            import json, os
            folder = os.path.dirname(self._file)
            if folder and not os.path.exists(folder):
                os.makedirs(folder, exist_ok=True)
            if os.path.exists(self._file):
                with open(self._file, 'r', encoding='utf-8') as f:
                    self.links = json.load(f)
            else:
                self.links = {}
        except Exception:
            self.links = {}

    def _save(self):
        try:
            import json
            with open(self._file, 'w', encoding='utf-8') as f:
                json.dump(self.links, f, indent=2)
        except Exception:
            pass
