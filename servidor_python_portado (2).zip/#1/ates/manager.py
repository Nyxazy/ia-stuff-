"""Features manager: safely import and instantiate known feature modules.

This loader tries to import feature modules that live in the `Features` folder
and instantiate their main classes if present. Failures are logged but do not
stop server startup.
"""
import importlib
import traceback

CLASS_MAP = {
    'anti_ddos_v3': 'AntiDDoS',
    'brawl_pass': 'BrawlPass',
    'region': 'RegionManager',
    'notifications': 'NotificationManager',
    'season_reset': 'SeasonReset',
    'store': 'Store',
    'clubs': 'ClubsManager',
    'boxes': 'BoxesManager',
    'gadgets': 'GadgetsManager',
    'stardrops': 'StarDrops',
    'pins': 'PinsManager',
    'rewards': 'RewardsCollector',
    'stats': 'StatsManager',
    'account_linking': 'AccountLinker',
    'server_admin': 'ServerAdmin'
}


class FeaturesManager:
    def __init__(self, server):
        self.server = server
        self.modules = {}

    def setup(self):
        # Try to import each known module and instantiate its main class.
        for mod_name, cls_name in CLASS_MAP.items():
            try:
                module = importlib.import_module(f'Features.{mod_name}')
            except Exception:
                # module not present or failed import
                continue

            try:
                cls = getattr(module, cls_name, None)
                if cls is None:
                    # fallback: try to find any class in module
                    for obj_name in dir(module):
                        obj = getattr(module, obj_name)
                        if isinstance(obj, type):
                            cls = obj
                            break

                if cls is None:
                    continue

                # instantiate with server if constructor accepts it, otherwise without args
                try:
                    instance = cls(self.server)
                except TypeError:
                    instance = cls()

                self.modules[mod_name] = instance
                # call start if available
                try:
                    if hasattr(instance, 'start'):
                        instance.start()
                except Exception:
                    print(f"[FeaturesManager] Failed to start {mod_name}:\n", traceback.format_exc())
            except Exception:
                print(f"[FeaturesManager] Error loading {mod_name}:\n", traceback.format_exc())

    def get(self, key):
        return self.modules.get(key)
