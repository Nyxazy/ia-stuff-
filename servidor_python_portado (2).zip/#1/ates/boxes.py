import random

class BoxesManager:
    def __init__(self, server):
        self.server = server

    def start(self):
        pass

    def open_box(self, player, box_type='normal'):
        # return a reward dict
        rewards = ['gold', 'gems', 'brawler_fragment']
        # extra reward chance
        if random.random() < 0.05:
            return {'reward': 'extra', 'amount': 1}
        return {'reward': random.choice(rewards), 'amount': random.randint(1, 100)}
