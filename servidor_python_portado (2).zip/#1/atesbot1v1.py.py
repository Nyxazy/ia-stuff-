import json
import logging
import os
import random
import shutil
import sqlite3
import string
import time
from pathlib import Path

import telebot

try:
    import psutil
except Exception:
    psutil = None

try:
    from Logic.Premium import (
        ensure_premium_columns,
        grant_premium_lowid,
        revoke_premium_lowid,
        get_premium_by_lowid,
        format_utc,
    )
except Exception:
    ensure_premium_columns = None
    grant_premium_lowid = None
    revoke_premium_lowid = None
    get_premium_by_lowid = None
    format_utc = lambda ts: str(ts)

try:
    from Logic.Notifications import add_notification_lowid
except Exception:
    add_notification_lowid = None

BOT_TOKEN = "8812129739:AAFgmGIE3NJCypIO527MaInFZiES0qxrLGc"
ADM_IDS = [8812129739]
MANAGER_IDS = []

ROOT = Path(__file__).resolve().parent
JSON_DIR = ROOT / "JSON"
JSON_DIR.mkdir(exist_ok=True)
DB_PATH = ROOT / "database" / "Player" / "plr.db"

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("telebot_admin")


def load_config():
    path = ROOT / "config.json"
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config(cfg):
    (ROOT / "config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=4), encoding="utf-8")


config = load_config()

if BOT_TOKEN and BOT_TOKEN != "PUT_YOUR_BOT_TOKEN_HERE":
    TELEGRAM_TOKEN = BOT_TOKEN
else:
    TELEGRAM_TOKEN = (
        os.environ.get("TELEGRAM_TOKEN")
        or config.get("telegram_token")
        or config.get("telebot_token")
        or config.get("bot_token")
    )

ADMIN_IDS = set(int(x) for x in ADM_IDS)
if MANAGER_IDS:
    MANAGER_IDS = set(int(x) for x in MANAGER_IDS) | ADMIN_IDS
else:
    MANAGER_IDS = set(ADMIN_IDS)


def is_admin(uid):
    return int(uid) in ADMIN_IDS


def is_manager(uid):
    return int(uid) in MANAGER_IDS or is_admin(uid)


def require_admin(message):
    if not is_admin(message.from_user.id):
        bot.reply_to(message, "🚫 You are not an administrator.")
        return False
    return True


def require_manager(message):
    if not is_manager(message.from_user.id):
        bot.reply_to(message, "🚫 You are not a manager/administrator.")
        return False
    return True


def send_long(chat_id, text):
    text = str(text)
    for i in range(0, len(text), 3900):
        bot.send_message(chat_id, text[i:i + 3900])


def db_connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    if ensure_premium_columns:
        try:
            ensure_premium_columns(conn)
        except Exception:
            pass
    return conn


def offers_file():
    for rel in ("JSON/offers.json", "Logic/offers.json", "offers.json"):
        p = ROOT / rel
        if p.exists():
            return p
    p = JSON_DIR / "offers.json"
    p.write_text("{}", encoding="utf-8")
    return p


def find_player_row(arg):
    conn = db_connect()
    cur = conn.cursor()
    try:
        lid = int(arg)
        cur.execute("SELECT * FROM plrs WHERE lowID=?", (lid,))
        row = cur.fetchone()
        if row:
            conn.close()
            return row, lid
    except Exception:
        pass
    try:
        cur.execute("SELECT * FROM plrs WHERE token=?", (arg,))
        row = cur.fetchone()
        if row:
            conn.close()
            return row, row[1]
    except Exception:
        pass
    try:
        cur.execute("SELECT * FROM plrs WHERE name=? COLLATE NOCASE", (arg,))
        row = cur.fetchone()
        if row:
            conn.close()
            return row, row[1]
    except Exception:
        pass
    conn.close()
    return None, None


def set_player_field_lowid(lowid, field, value):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute(f"UPDATE plrs SET {field}=? WHERE lowID=?", (value, int(lowid)))
    conn.commit()
    conn.close()


def add_player_field_lowid(lowid, field, amount):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute(f"SELECT {field} FROM plrs WHERE lowID=?", (int(lowid),))
    row = cur.fetchone()
    current = int(row[0] or 0) if row else 0
    new_value = current + int(amount)
    cur.execute(f"UPDATE plrs SET {field}=? WHERE lowID=?", (new_value, int(lowid)))
    conn.commit()
    conn.close()
    return new_value


def update_brawlerdata_for_lowid(lowid, modifier_fn):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT brawlerData FROM plrs WHERE lowID=?", (int(lowid),))
    row = cur.fetchone()
    if not row:
        conn.close()
        return False
    try:
        data = json.loads(row[0])
    except Exception:
        data = {}
    modifier_fn(data)
    cur.execute("UPDATE plrs SET brawlerData=? WHERE lowID=?", (json.dumps(data, ensure_ascii=False), int(lowid)))
    conn.commit()
    conn.close()
    return True


def add_notification(account_code, message, kind=81, **kwargs):
    if add_notification_lowid is None:
        return False
    add_notification_lowid(account_code, message=str(message), kind=kind, **kwargs)
    return True


def all_lowids():
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT lowID FROM plrs")
    rows = [r[0] for r in cur.fetchall()]
    conn.close()
    return rows


def grant_gems(account_code, amount, reason="Admin"):
    row, lowid = find_player_row(account_code)
    if lowid is None:
        raise ValueError("Account not found")
    add_notification(lowid, f"You received {amount} gems. Reason: {reason}", kind=89, DonationCount=int(amount))
    return lowid, int(amount)


def grant_premium(account_code, months=1, level=1):
    row, lowid = find_player_row(account_code)
    if lowid is None:
        raise ValueError("Account not found")
    if grant_premium_lowid is None:
        raise RuntimeError("Logic.Premium is not available")
    end = grant_premium_lowid(lowid, months=int(months), level=int(level))
    add_notification(lowid, f"Premium level {level} activated/extended for {months} month(s). Expires at {format_utc(end)}", kind=81)
    try:
        from Logic.Premium import premium_reward_config, mark_premium_reward_claimed
        reward = premium_reward_config(level)
        if reward:
            add_notification(lowid, f"Premium reward: {reward['gems']} gems and {reward['gold']} coins.", kind=89, DonationCount=reward['gems'], GoldCount=reward['gold'], Kind="premium_reward")
            mark_premium_reward_claimed(lowid=lowid)
    except Exception:
        pass
    return lowid, end


def revoke_premium(account_code):
    row, lowid = find_player_row(account_code)
    if lowid is None:
        raise ValueError("Account not found")
    if revoke_premium_lowid is None:
        raise RuntimeError("Logic.Premium is not available")
    revoke_premium_lowid(lowid)
    add_notification(lowid, "Your Premium was removed by an administrator.", kind=81)
    return lowid


def help_text():
    return """
🤖 100% TeleBot Admin Bot

Basic commands:
/start, /ahelp, /help, /ping, /status
/getjson, /addjson, send a .json file to update offers
/list, /new_offer, /remove_offer

Account/resources:
/gems ID amount
/add_gems ID amount
/add_gold ID amount
/add_trophies ID amount
/change_name ID name

Premium:
/premium ID [months] [level 1-3]
/prem ID [months] [level]
/vip ID, /vipplus ID, /ultravip ID, /megavip ID, /developervip ID
/del_premium ID, /del_prem ID
/premium_info ID

General admin:
/ban ID, /unban ID
/clear_room
/theme ID
/enable_maintenance, /disable_maintenance
/new_code code, /del_code code, /code_list
/addnotiftoall message
/addpopuptoall
/addgemstoall message-translation-amount
/unlockall ID, /allskins ID
/battle ID
/idtonumber ID, /numbertoid number
/addbackup ID
/addword word, /deleteword word
/addcreator CODE LOWID [REWARD_DEFAULT_0]
/deletecreator CODE
/creatorlist
/addgems CODE GEMS USES
/addcoins CODE COINS USES
/addskin CODE SKIN_ID USES
/deletepromo CODE
/promolist
/skinid name
/bakiye trickz
/debugmenu
""".strip()



if not TELEGRAM_TOKEN:
    raise RuntimeError("Set BOT_TOKEN at the top of atesbot1v1.py.py")

bot = telebot.TeleBot(TELEGRAM_TOKEN, parse_mode=None)


@bot.message_handler(commands=["start", "ahelp", "help"])
def cmd_start(message):
    send_long(message.chat.id, help_text())


@bot.message_handler(commands=["ping"])
def cmd_ping(message):
    bot.reply_to(message, "🏓 Pong!")


@bot.message_handler(commands=["status"])
def cmd_status(message):
    if not require_manager(message):
        return
    online = "?"
    total = "?"
    premium = "?"
    try:
        conn = db_connect()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM plrs")
        total = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM plrs WHERE online>0")
        online = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM plrs WHERE premiumLevel>0 AND premiumEndTime>strftime('%s','now')")
        premium = cur.fetchone()[0]
        conn.close()
    except Exception:
        pass
    mem = "?"
    cpu = "?"
    if psutil:
        try:
            mem = f"{psutil.virtual_memory().percent}%"
            cpu = f"{psutil.cpu_percent()}%"
        except Exception:
            pass
    bot.reply_to(message, f"📊 Status\nAccounts: {total}\nOnline: {online}\nActive Premium: {premium}\nRAM: {mem}\nCPU: {cpu}")


@bot.message_handler(commands=["getjson"])
def cmd_getjson(message):
    if not require_admin(message):
        return
    p = offers_file()
    with p.open("rb") as f:
        bot.send_document(message.chat.id, f, visible_file_name=p.name)


@bot.message_handler(commands=["addjson"])
def cmd_addjson(message):
    if not require_admin(message):
        return
    doc_msg = message.reply_to_message if message.reply_to_message and message.reply_to_message.document else message
    if not getattr(doc_msg, "document", None):
        bot.reply_to(message, "Reply to a .json file with /addjson or send the .json file directly.")
        return
    save_json_document(doc_msg, message.chat.id)


@bot.message_handler(content_types=["document"])
def handle_document(message):
    if not is_admin(message.from_user.id):
        return
    if message.document.file_name.lower().endswith(".json"):
        save_json_document(message, message.chat.id)


def save_json_document(message, chat_id):
    if not message.document.file_name.lower().endswith(".json"):
        bot.send_message(chat_id, "Only .json files are accepted.")
        return
    info = bot.get_file(message.document.file_id)
    content = bot.download_file(info.file_path)
                                 
    json.loads(content.decode("utf-8"))
    p = offers_file()
    p.write_bytes(content)
    bot.send_message(chat_id, f"✅ JSON saved to {p.relative_to(ROOT)}")


@bot.message_handler(commands=["list"])
def cmd_list_offers(message):
    p = offers_file()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        bot.reply_to(message, f"Error reading offers: {e}")
        return
    if not data:
        bot.reply_to(message, "No offers found.")
        return
    text = "Offer list:\n"
    for offer_id, offer in data.items():
        text += f"\nOffer #{offer_id}\nTitle: {offer.get('OfferTitle')}\nCost: {offer.get('Cost')}\n"
    send_long(message.chat.id, text)


@bot.message_handler(commands=["new_offer"])
def cmd_new_offer(message):
    if not require_admin(message):
        return
    parts = message.text.split()
    if len(parts) < 10:
        bot.reply_to(message, "Usage: /new_offer ID OfferTitle Cost Multiplier BrawlerID SkinID OfferBGR ShopType ShopDisplay")
        return
    p = offers_file()
    data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    offer = {
        "ID": [int(parts[1]), 0, 0],
        "OfferTitle": parts[2],
        "Cost": int(parts[3]),
        "OldCost": 0,
        "Multiplier": [int(parts[4]), 0, 0],
        "BrawlerID": [int(parts[5]), 0, 0],
        "SkinID": [int(parts[6]), 0, 0],
        "WhoBuyed": [],
        "Timer": 86400,
        "OfferBGR": parts[7],
        "ShopType": int(parts[8]),
        "ShopDisplay": int(parts[9]),
    }
    data[str(len(data))] = offer
    p.write_text(json.dumps(data, ensure_ascii=False, indent=4), encoding="utf-8")
    bot.reply_to(message, "✅ New offer added.")


@bot.message_handler(commands=["remove_offer"])
def cmd_remove_offer(message):
    if not require_admin(message):
        return
    parts = message.text.split()
    if len(parts) != 2:
        bot.reply_to(message, "Usage: /remove_offer ID")
        return
    p = offers_file()
    data = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    if parts[1] not in data:
        bot.reply_to(message, "Offer not found.")
        return
    data.pop(parts[1])
    p.write_text(json.dumps(data, ensure_ascii=False, indent=4), encoding="utf-8")
    bot.reply_to(message, "✅ Offer removed.")


@bot.message_handler(commands=["gems", "add_gems"])
def cmd_gems(message):
    if not require_manager(message):
        return
    parts = message.text.split()
    if len(parts) != 3:
        bot.reply_to(message, "Usage: /gems ID amount")
        return
    try:
        lowid, new_value = grant_gems(parts[1], int(parts[2]), reason=f"TeleBot:{message.from_user.id}")
        bot.reply_to(message, f"✅ Gems notification added to inbox. ID: {lowid}, amount: {new_value}.")
    except Exception as e:
        bot.reply_to(message, f"Error: {e}")


@bot.message_handler(commands=["add_gold", "add_trophies"])
def cmd_set_resource(message):
    if not require_admin(message):
        return
    parts = message.text.split()
    if len(parts) != 3:
        bot.reply_to(message, f"Usage: /{message.text.split()[0].lstrip('/')} ID amount")
        return
    field = "gold" if message.text.startswith("/add_gold") else "trophies"
    row, lowid = find_player_row(parts[1])
    if lowid is None:
        bot.reply_to(message, "Account not found.")
        return
    set_player_field_lowid(lowid, field, int(parts[2]))
    bot.reply_to(message, f"✅ {field} for {lowid} set to {parts[2]}.")


@bot.message_handler(commands=["change_name"])
def cmd_change_name(message):
    if not require_admin(message):
        return
    parts = message.text.split(maxsplit=2)
    if len(parts) != 3:
        bot.reply_to(message, "Usage: /change_name ID name")
        return
    row, lowid = find_player_row(parts[1])
    if lowid is None:
        bot.reply_to(message, "Account not found.")
        return
    set_player_field_lowid(lowid, "name", parts[2])
    bot.reply_to(message, f"✅ Name for {lowid} changed to {parts[2]}.")


@bot.message_handler(commands=["premium", "prem", "add_premium", "vip", "vipplus", "ultravip", "megavip", "developervip"])
def cmd_premium(message):
    if not require_manager(message):
        return
    parts = message.text.split()
    cmd = parts[0].lstrip("/").lower()
    if len(parts) < 2:
        bot.reply_to(message, "Usage: /premium ID [months] [level 1-3]")
        return
    months = int(parts[2]) if len(parts) >= 3 else 1
    level = int(parts[3]) if len(parts) >= 4 else 1
    if cmd == "vipplus":
        months, level = 1, 2
    elif cmd == "ultravip":
        months, level = 3, 2
    elif cmd == "megavip":
        months, level = 6, 3
    elif cmd == "developervip":
        months, level = 12000, 3
    level = max(1, min(level, 3))
    try:
        lowid, end = grant_premium(parts[1], months, level)
        bot.reply_to(message, f"✅ Premium activated/extended\nID: {lowid}\nLevel: {level}\nMonths: {months}\nExpires at: {format_utc(end)}")
    except Exception as e:
        bot.reply_to(message, f"Error: {e}")


@bot.message_handler(commands=["del_premium", "remove_premium", "del_prem", "del_vip"])
def cmd_del_premium(message):
    if not require_manager(message):
        return
    parts = message.text.split()
    if len(parts) != 2:
        bot.reply_to(message, "Usage: /del_premium ID")
        return
    try:
        lowid = revoke_premium(parts[1])
        bot.reply_to(message, f"✅ Premium removed from ID {lowid}.")
    except Exception as e:
        bot.reply_to(message, f"Error: {e}")


@bot.message_handler(commands=["premium_info"])
def cmd_premium_info(message):
    if not require_manager(message):
        return
    parts = message.text.split()
    if len(parts) != 2:
        bot.reply_to(message, "Usage: /premium_info ID")
        return
    row, lowid = find_player_row(parts[1])
    if lowid is None:
        bot.reply_to(message, "Account not found.")
        return
    level, end, notice = get_premium_by_lowid(lowid) if get_premium_by_lowid else (0, 0, 0)
    active = level > 0 and end > int(time.time())
    bot.reply_to(message, f"ID: {lowid}\nPremium active: {active}\nLevel: {level}\nExpires at: {format_utc(end)}")


@bot.message_handler(commands=["unlockall", "allskins"])
def cmd_unlocks(message):
    if not require_admin(message):
        return
    parts = message.text.split()
    if len(parts) != 2:
        bot.reply_to(message, "Usage: /unlockall ID or /allskins ID")
        return
    row, lowid = find_player_row(parts[1])
    if lowid is None:
        bot.reply_to(message, "Account not found.")
        return
    cmd = parts[0].lstrip("/").lower()
    def modifier(data):
        if cmd == "unlockall":
            data.setdefault("UnlockedBrawlers", {})
            for i in range(200):
                data["UnlockedBrawlers"][str(i)] = 1
        data.setdefault("UnlockedSkins", {})
        for i in range(400):
            data["UnlockedSkins"][str(i)] = 1
    ok = update_brawlerdata_for_lowid(lowid, modifier)
    bot.reply_to(message, f"✅ {cmd} applied to {lowid}." if ok else "Apply failed.")


@bot.message_handler(commands=["addnotiftoall"])
def cmd_notif_all(message):
    if not require_admin(message):
        return
    msg = message.text.partition(" ")[2].strip()
    if not msg:
        bot.reply_to(message, "Usage: /addnotiftoall message")
        return
    for lowid in all_lowids():
        add_notification(lowid, msg, kind=81)
    bot.reply_to(message, "✅ Notification sent to everyone.")


@bot.message_handler(commands=["addpopuptoall"])
def cmd_popup_all(message):
    if not require_admin(message):
        return
    msg = message.text.partition(" ")[2].strip() or "Premium event started."
    for lowid in all_lowids():
        add_notification(lowid, msg, kind=83)
    bot.reply_to(message, "✅ Popup sent to everyone.")


@bot.message_handler(commands=["addgemstoall"])
def cmd_gems_all(message):
    if not require_admin(message):
        return
    parts = message.text.split("-", 3)
    if len(parts) != 4:
        bot.reply_to(message, "Usage: /addgemstoall message-translation-amount")
        return
    try:
        amount = int(parts[3].strip())
    except Exception:
        bot.reply_to(message, "Invalid amount.")
        return
    count = 0
    for lowid in all_lowids():
        try:
            grant_gems(lowid, amount, reason=parts[1].strip())
            count += 1
        except Exception:
            pass
    bot.reply_to(message, f"✅ Gems sent to {count} players.")


@bot.message_handler(commands=["ban", "unban"])
def cmd_ban(message):
    if not require_admin(message):
        return
    parts = message.text.split()
    if len(parts) < 2:
        bot.reply_to(message, "Usage: /ban ID or /unban ID")
        return
    lowid = int(parts[1])
    cfg = load_config()
    cfg.setdefault("banID", [])
    if message.text.startswith("/ban"):
        if lowid not in cfg["banID"]:
            cfg["banID"].append(lowid)
        save_config(cfg)
        bot.reply_to(message, f"✅ Ban applied to ID {lowid}.")
    else:
        if lowid in cfg["banID"]:
            cfg["banID"].remove(lowid)
        save_config(cfg)
        bot.reply_to(message, f"✅ Ban removed from ID {lowid}.")


@bot.message_handler(commands=["clear_room"])
def cmd_clear_room(message):
    if not require_admin(message):
        return
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("UPDATE plrs SET roomID=0")
    conn.commit()
    conn.close()
    bot.reply_to(message, "✅ Rooms cleared.")


@bot.message_handler(commands=["theme"])
def cmd_theme(message):
    if not require_admin(message):
        return
    parts = message.text.split()
    if len(parts) != 2:
        bot.reply_to(message, "Usage: /theme ID")
        return
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("UPDATE plrs SET theme=?", (int(parts[1]),))
    conn.commit()
    conn.close()
    bot.reply_to(message, f"✅ Global theme changed to {parts[1]}.")


@bot.message_handler(commands=["enable_maintenance", "disable_maintenance"])
def cmd_maintenance(message):
    if not require_admin(message):
        return
    cfg = load_config()
    enabled = message.text.startswith("/enable")
    cfg["maintenance"] = enabled
    cfg["Maintenance"] = enabled
    save_config(cfg)
    bot.reply_to(message, "✅ Maintenance enabled." if enabled else "✅ Maintenance disabled.")


@bot.message_handler(commands=["new_code", "del_code", "code_list"])
def cmd_creator_codes(message):
    if not require_admin(message) and not message.text.startswith("/code_list"):
        return
    cfg = load_config()
    cfg.setdefault("CCC", [])
    parts = message.text.split()
    cmd = parts[0].lstrip("/")
    if cmd == "code_list":
        send_long(message.chat.id, "Codes:\n" + "\n".join(cfg.get("CCC", [])))
        return
    if len(parts) != 2:
        bot.reply_to(message, f"Usage: /{cmd} code")
        return
    code = parts[1]
    if cmd == "new_code":
        if code not in cfg["CCC"]:
            cfg["CCC"].append(code)
        save_config(cfg)
        bot.reply_to(message, "✅ Code added.")
    else:
        if code in cfg["CCC"]:
            cfg["CCC"].remove(code)
        save_config(cfg)
        bot.reply_to(message, "✅ Code removed.")


@bot.message_handler(commands=["battle"])
def cmd_battle(message):
    if not require_admin(message):
        return
    parts = message.text.split()
    if len(parts) != 2:
        bot.reply_to(message, "Usage: /battle ID")
        return
    p = ROOT / "battles.txt"
    if not p.exists():
        bot.reply_to(message, "battles.txt not found.")
        return
    lines = [l for l in p.read_text(encoding="utf-8", errors="ignore").splitlines() if f"Player #{parts[1]}" in l]
    if not lines:
        bot.reply_to(message, "No battle log found.")
        return
    tmp = ROOT / f"battle_{parts[1]}.txt"
    tmp.write_text("\n".join(lines), encoding="utf-8")
    with tmp.open("rb") as f:
        bot.send_document(message.chat.id, f, visible_file_name=tmp.name)
    tmp.unlink(missing_ok=True)


@bot.message_handler(commands=["idtonumber", "numbertoid"])
def cmd_id_number(message):
    if not require_admin(message):
        return
    parts = message.text.split()
    if len(parts) != 2:
        bot.reply_to(message, "Usage: /idtonumber ID or /numbertoid number")
        return
    try:
        bot.reply_to(message, str(int(parts[1])))
    except Exception:
        bot.reply_to(message, "Invalid format. Use numeric lowID.")


@bot.message_handler(commands=["addbackup"])
def cmd_backup(message):
    if not require_admin(message):
        return
    parts = message.text.split()
    if len(parts) != 2:
        bot.reply_to(message, "Usage: /addbackup ID")
        return
    code = "".join(random.choices(string.ascii_uppercase, k=3)) + "-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
    tmp = ROOT / f"{code}.txt"
    tmp.write_text(parts[1], encoding="utf-8")
    bot.reply_to(message, f"Backup created: {code}")
    with tmp.open("rb") as f:
        bot.send_document(message.chat.id, f, visible_file_name=tmp.name)


@bot.message_handler(commands=["addword", "deleteword", "addcreator", "deletecreator", "creatorlist", "addpromo", "deletepromo", "promolist", "addgems", "addcoins", "addskin"])
def cmd_words_creators(message):
    if not require_admin(message):
        return
    parts = message.text.split()
    cmd = parts[0].lstrip("/")
    words_file = ROOT / "words.json"
    if cmd in ("addword", "deleteword"):
        if len(parts) != 2:
            bot.reply_to(message, f"Usage: /{cmd} word")
            return
        arr = json.loads(words_file.read_text(encoding="utf-8")) if words_file.exists() else []
        if cmd == "addword" and parts[1] not in arr:
            arr.append(parts[1])
        if cmd == "deleteword" and parts[1] in arr:
            arr.remove(parts[1])
        words_file.write_text(json.dumps(arr, ensure_ascii=False, indent=2), encoding="utf-8")
        bot.reply_to(message, "✅ Done")
        return

    if cmd in ("addcreator", "deletecreator", "creatorlist"):
        from Logic.Creators import add_creator, delete_creator, list_creators
        if cmd == "creatorlist":
            creators = list_creators()
            bot.reply_to(message, "Creators:\n" + "\n".join([f"{c.get('Code')} -> lowID {c.get('LowID')} reward {c.get('RewardCount', 0)}" for c in creators]) if creators else "No creator found.")
            return
        if cmd == "addcreator":
            if len(parts) < 3:
                bot.reply_to(message, "Usage: /addcreator CODE LOWID [REWARD_DEFAULT_0]")
                return
            reward = int(parts[3]) if len(parts) >= 4 else 0
            creator = add_creator(parts[1], int(parts[2]), reward)
            bot.reply_to(message, f"✅ Creator added: {creator.get('Code')} -> lowID {creator.get('LowID')} reward {creator.get('RewardCount')} (creator support should not reward player)")
            return
        if cmd == "deletecreator":
            if len(parts) != 2:
                bot.reply_to(message, "Usage: /deletecreator CODE")
                return
            ok = delete_creator(parts[1])
            bot.reply_to(message, "✅ Creator removed." if ok else "Creator not found.")
            return

    if cmd in ("addpromo", "deletepromo", "promolist", "addgems", "addcoins", "addskin"):
        from Logic.PromoCodes import add_promo, delete_promo, list_promos
        if cmd == "promolist":
            promos = list_promos()
            bot.reply_to(message, "Promos:\n" + "\n".join([f"{p.get('Code')} -> {p.get('Items', [{}])[0].get('Type')} x{p.get('Items', [{}])[0].get('Count')} max {p.get('MaxActivations')}" for p in promos]) if promos else "No promo found.")
            return
        if cmd == "deletepromo":
            if len(parts) != 2:
                bot.reply_to(message, "Usage: /deletepromo CODE")
                return
            ok = delete_promo(parts[1])
            bot.reply_to(message, "✅ Promo removed." if ok else "Promo not found.")
            return
        if cmd == "addgems":
            if len(parts) != 4:
                bot.reply_to(message, "Usage: /addgems CODE GEMS USES")
                return
            promo = add_promo(parts[1], 'gems', amount=int(parts[2]), max_activations=int(parts[3]))
            bot.reply_to(message, f"✅ Promo gems criado: {promo.get('Code')} -> {parts[2]} gems / usos {parts[3]}")
            return
        if cmd == "addcoins":
            if len(parts) != 4:
                bot.reply_to(message, "Usage: /addcoins CODE COINS USES")
                return
            promo = add_promo(parts[1], 'coin', amount=int(parts[2]), max_activations=int(parts[3]))
            bot.reply_to(message, f"✅ Promo coins criado: {promo.get('Code')} -> {parts[2]} coins / usos {parts[3]}")
            return
        if cmd == "addskin":
            if len(parts) != 4:
                bot.reply_to(message, "Usage: /addskin CODE SKIN_ID USES")
                return
            promo = add_promo(parts[1], 'skin', amount=1, skin_id=int(parts[2]), max_activations=int(parts[3]))
            bot.reply_to(message, f"✅ Promo skin criado: {promo.get('Code')} -> skin {parts[2]} / usos {parts[3]}")
            return
        if cmd == "addpromo":
            if len(parts) < 4:
                bot.reply_to(message, "Usage: /addpromo CODE TYPE AMOUNT [SKIN_ID]")
                return
            code = parts[1]
            item_type = parts[2].lower()
            amount = int(parts[3])
            skin_id = int(parts[4]) if len(parts) >= 5 else 0
            brawler_id = int(parts[4]) if len(parts) >= 5 and item_type == 'brawler' else 0
            promo = add_promo(code, item_type, amount=amount, skin_id=skin_id if item_type == 'skin' else 0, brawler_id=brawler_id, max_activations=1000)
            bot.reply_to(message, f"✅ Promo added: {promo.get('Code')} -> {item_type} x{amount}")
            return


@bot.message_handler(commands=["skinid"])
def cmd_skinid(message):
    if not require_admin(message):
        return
    term = message.text.partition(" ")[2].strip()
    if not term:
        bot.reply_to(message, "Usage: /skinid name")
        return
    for rel in ("skinids.txt", "Logic/skins.txt", "Logic/skinsIdByDitaDevII.txt"):
        p = ROOT / rel
        if p.exists():
            lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()
            res = [l for l in lines if term.lower() in l.lower()][:20]
            bot.reply_to(message, "Results:\n" + "\n".join(res) if res else "Nothing found.")
            return
    bot.reply_to(message, "Skin file not found.")


@bot.message_handler(commands=["bakiye"])
def cmd_bakiye(message):
    if not require_admin(message):
        return
    p = ROOT / "trickzbakiye.txt"
    if not p.exists():
        bot.reply_to(message, "Balance file not found.")
        return
    bot.reply_to(message, p.read_text(encoding="utf-8", errors="ignore")[:3900])


@bot.message_handler(commands=["debugmenu"])
def cmd_debug(message):
    if not require_admin(message):
        return
    bot.reply_to(message, "🛠️ Debug menu active. Use /status, /getjson, /battle ID and admin commands.")


@bot.message_handler(func=lambda m: True)
def fallback(message):
    if message.text and message.text.startswith("/"):
        bot.reply_to(message, "Command not recognized. Use /ahelp.")


def run_bot():
    logger.info("Starting 100%% TeleBot bot...")
    bot.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=30)


if __name__ == "__main__":
    run_bot()
