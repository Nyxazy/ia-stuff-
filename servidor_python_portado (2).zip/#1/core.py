import socket
import time
import os
import sqlite3
import json
from threading import Thread, Lock
from database.DataBase import DataBase
from Logic.Device import Device
from Logic.Player import Players
from Logic.LogicMessageFactory import packets
from Utils.Config import Config
from Utils.Helpers import Helpers
from shared import connected_ips
from Logic.AntiCheat import AntiCheat
from Logic.Premium import ensure_premium_columns
from Logic.Notifications import ensure_notification_columns
try:
    from Features.manager import FeaturesManager
except Exception:
    try:
        from ates.manager import FeaturesManager
    except Exception:
        FeaturesManager = None
try:
    from Logic.auth import AuthManager
except Exception:
    AuthManager = None
import asyncio

addr = {}
block = []
addr_lock = Lock()

def log_info(*args):
    print('[BİLGİ]', *args)

class Server:
    Clients = {"ClientCounts": 0, "Clients": {}}
    ThreadCount = 0
    MAX_THREADS = 99999999            
    MAX_BYTES_PER_SECOND = 20480

    def __init__(self, ip: str, port: int):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.port = port
        self.ip = ip
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        # DisableNagle: desabilita o algoritmo de Nagle no socket do servidor
        # Reduz delay e melhora a performance entre cliente e servidor, MAS consome mais recursos
        self.disable_nagle = Config.GetValue().get("DisableNagle", False)
        if self.disable_nagle:
            self.server.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, True)
            log_info('[DisableNagle] TCP_NODELAY ativado no socket do servidor')

        self.server.bind((self.ip, self.port))
        log_info(f'Lobi başlatıldı! {self.ip}:{self.port}')
        self.clear_blocked_ips_in_config()
        self.clear_connected_ips()
        
        self.setup_database()
        self.total_sent_bytes = 0
        self.total_received_bytes = 0
        self.blocked_ips = set()
        self.reported_blocked_ips = set()
        self.last_warning_time = 0
        try:
            self.anti_cheat = AntiCheat(self)
            self.anti_cheat.start_cleanup_loop()
        except Exception:
            self.anti_cheat = None

        
        try:
            if FeaturesManager is not None:
                self.features = FeaturesManager(self)
                self.features.setup()
            else:
                self.features = None
        except Exception as e:
            log_info(f"Features manager init failed: {e}")

        
        try:
            if AuthManager is not None:
                self.auth = AuthManager(db_path='database/auth.db')
                ok, msg = self.auth.init_db()
                if not ok:
                    log_info(f"Auth DB init failed: {msg}")
            else:
                self.auth = None
        except Exception as e:
            log_info(f"Auth init error: {e}")
            self.auth = None

        Thread(target=self.monitor_load, daemon=True).start()
        Thread(target=self.clean_database_periodically, daemon=True).start()

    def clear_blocked_ips_in_config(self):
        with open('config.json', 'r') as config_file:
            settings = json.load(config_file)
        settings['block'] = []
        with open('config.json', 'w') as config_file:
            json.dump(settings, config_file, indent=4)
        log_info("Başlangıçta `config.json` içindeki engellenen IP'ler temizlendi")

    def setup_database(self):
        if os.path.exists("database/Player/plr.db"):
            with sqlite3.connect("database/Player/plr.db") as conn:
                c = conn.cursor()
                c.execute("UPDATE plrs SET roomID=0")
                c.execute("UPDATE plrs SET online=0")
                ensure_premium_columns(conn)
                ensure_notification_columns(conn)
                conn.commit()
        else:
            with sqlite3.connect("database/Player/plr.db") as conn:
                c = conn.cursor()
                c.execute(""" 
                    CREATE TABLE IF NOT EXISTS plrs (
                        token TEXT, lowID INT, name TEXT, trophies INT, gold INT, gems INT, 
                        starpoints INT, tickets INT, Troproad INT, profile_icon INT, 
                        name_color INT, clubID INT, clubRole INT, brawlerData JSON, 
                        brawlerID INT, skinID INT, roomID INT, box INT, bigbox INT, 
                        online INT, vip INT, playerExp INT, friends JSON, SCC TEXT, 
                        trioWINS INT, sdWINS INT, theme INT, BPTOKEN INT, BPXP INT, 
                        quests JSON, freepass INT, buypass INT, notifRead INT, notifRead2 INT,
                        ip_address TEXT, creation_date TEXT, Region TEXT,
                        premiumLevel INT DEFAULT 0, premiumEndTime INT DEFAULT 0, premiumExpireNotice INT DEFAULT 0, premiumLastRewardTime INT DEFAULT 0, notifications TEXT DEFAULT '[]'
                    )
                """)
                ensure_premium_columns(conn)
                ensure_notification_columns(conn)
                conn.commit()

    def clean_database_periodically(self):
        while True:
            time.sleep(3600)
            try:
                with sqlite3.connect("database/Player/plr.db") as conn:
                    c = conn.cursor()
                    c.execute("DELETE FROM plrs WHERE gold=100 AND trioWINS=0 AND trophies > 0")
                    log_info("Veritabanı botlardan temizlendi.")
                    conn.commit()
            except Exception as e:
                log_info(f"Veritabanı temizleme hatası: {e}")

    def start(self):
        while True:
            self.server.listen()
            try:
                client, address = self.server.accept()
            except Exception as e:
                log_info(f"Bağlantı kabul hatası: {e}")
                continue

            with addr_lock:
                if Server.ThreadCount >= self.MAX_THREADS:
                    if time.time() - self.last_warning_time > 10:
                        log_info(f"İş parçacığı sayısı aşıldı ({Server.ThreadCount}). Bağlantı kapatıldı.")
                        self.last_warning_time = time.time()
                    client.close()
                    continue

                self.log_connection(address[0])

               
                try:
                    anti = None
                    if hasattr(self, 'features'):
                        anti = self.features.get('anti_ddos')
                    if anti:
                        anti.record_connection(address[0])
                        if anti.check_connection(address[0]):
                            if address[0] not in self.blocked_ips:
                                log_info(f"[AntiDDoS v3] IP engellendi (özellik modülü): {address[0]}")
                                self.blocked_ips.add(address[0])
                                self.update_blocked_clients(address[0])
                            client.close()
                            continue
                except Exception as e:
                    log_info(f"Features AntiDDoS kontrolü başarısız: {e}")

                if address[0] in self.blocked_ips:
                    if address[0] not in self.reported_blocked_ips:
                        log_info(f"[AntiDDoS] IP engellendi: {address[0]}")
                        self.log_blocked_ip(address[0])
                        self.reported_blocked_ips.add(address[0])
                    client.close()
                    continue

                try:
                    if hasattr(self, 'anti_cheat') and self.anti_cheat and self.anti_cheat.check_ip(address[0]):
                        client.close()
                        continue
                except Exception as e:
                    log_info(f"AntiCheat kontrolü başarısız: {e}")

                addr[address[0]] = addr.get(address[0], 0) + 1

                if addr[address[0]] >= 22:
                    if address[0] not in self.blocked_ips:
                        log_info(f"[AntiDDoS] IP koruması etkinleştirildi: {address[0]}")
                        self.blocked_ips.add(address[0])
                        self.update_blocked_clients(address[0])
                    client.close()
                else:
                    # DisableNagle: aplica TCP_NODELAY no socket do cliente aceito
                    # Isso é ESSENCIAL porque TCP_NODELAY no listening socket NÃO propaga pros sockets aceitos
                    if self.disable_nagle:
                        try:
                            client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, True)
                        except Exception:
                            pass

                    connected_ips.add(address[0])
                    ClientThread(client, address, self).start()
                    Server.ThreadCount += 1
                    
    def clear_connected_ips(self):
        with open('JSON/ConnectedIP.json', 'w') as log_file:
            json.dump([], log_file, indent=4)
        log_info("Sunucu başlatılırken ConnectedIP.json dosyası temizlendi.")

    def log_connection(self, ip):
        moscow_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() + 3 * 3600))                      
        with sqlite3.connect("database/Player/plr.db") as conn:
            c = conn.cursor()
           
            region = self.detect_region_from_ip(ip)
            try:
                c.execute("SELECT lowID, name FROM plrs WHERE SCC = ?", (ip,))
                result = c.fetchone()
            except Exception:
                result = None

        log_data = {
            "time": moscow_time,
            "ip": ip
        }

        with open('JSON/ConnectedIP.json', 'a') as log_file:
            json.dump(log_data, log_file, ensure_ascii=False, indent=4)
            log_file.write('\n')

        log_info(f"Bağlantı: {log_data}")

    def detect_region_from_ip(self, ip: str) -> str:
        try:
            first_octet = int(ip.split('.')[0])
            if 1 <= first_octet <= 49:
                return 'Europe/Asia'
            if 50 <= first_octet <= 99:
                return 'Americas'
            if 100 <= first_octet <= 149:
                return 'Asia'
            if 150 <= first_octet <= 199:
                return 'Africa/Asia'
            return 'Unknown'
        except Exception:
            return 'Unknown'

    def log_blocked_ip(self, ip):
        with open('JSON/blocked_ips.log', 'a') as log_file:
            log_file.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} - IP Engellendi: {ip}\n")

    def update_blocked_clients(self, ip):
        with open('config.json', 'r') as config_file:
            settings = json.load(config_file)
        
        if ip not in settings['block']:
            settings['block'].append(ip)
        
        with open('config.json', 'w') as config_file:
            json.dump(settings, config_file, indent=4)
            
        log_info(f"Engellenen IP'ler: {settings['block']}")


    def monitor_load(self):
        while True:
            time.sleep(3600)
            log_info("Bağlantılar izleniyor...")


    
    def register_user(self, username: str, password: str):

        if not hasattr(self, 'auth') or self.auth is None:
            return False, 'Auth sistemi mevcut değil.'
        return self.auth.register_user(username, password)

    def login_user(self, username: str, password: str):
     
        if not hasattr(self, 'auth') or self.auth is None:
            return False, 'Auth sistemi mevcut değil.'
        return self.auth.login_user(username, password)

    def logout_user(self, username: str):
        if not hasattr(self, 'auth') or self.auth is None:
            return False, 'Auth sistemi mevcut değil.'
        return self.auth.logout_user(username)

def ip_to_int(ip):
    return int.from_bytes(socket.inet_aton(ip), 'big')

class ClientThread(Thread):
    MAX_RECEIVE_BYTES = 20480
    MAX_BYTES_PER_SECOND = 20480

    def __init__(self, client, address, server):
        super().__init__()
        self.client = client
        self.address = address
        self.device = Device(self.client)
        self.player = Players(self.device)
        self.server = server
        self.total_received_bytes = 0
        self.total_sent_bytes = 0
        self.bytes_received_in_last_second = 0
        self.last_packet_time = time.time()
        self.packet_count = 0

    def recvall(self, length):
        data = b''
        while len(data) < length:
            packet = self.client.recv(length - len(data))
            if not packet:
                break
            data += packet
        return data

    def run(self):
        client_ip = self.address[0]
        try:
            client_ip = self.client.getpeername()[0]
            self.player.ip_address = self.client.getpeername()[0]

           
            try:
                if hasattr(self.server, 'features'):
                    region_mod = self.server.features.get('region')
                    if region_mod:
                        try:
                            region = region_mod.detect_region(client_ip)
                            self.player.Region = region
                         
                            try:
                                with sqlite3.connect('database/Player/plr.db') as conn:
                                    c = conn.cursor()
                                    c.execute('UPDATE plrs SET Region = ?, ip_address = ? WHERE SCC = ?', (region, client_ip, client_ip))
                                    conn.commit()
                            except Exception:
                                pass
                        except Exception:
                            pass
            except Exception:
                pass
            while True:
                header = self.client.recv(7)
                if len(header) > 0:
                    packet_id = int.from_bytes(header[:2], 'big')
                    length = int.from_bytes(header[2:5], 'big')
                    data = self.recvall(length)

                    self.total_received_bytes += length
                    self.server.total_sent_bytes += length
                    self.bytes_received_in_last_second += length
                    self.packet_count += 1

                    if time.time() - self.last_packet_time >= 1:
                        if self.bytes_received_in_last_second > self.MAX_BYTES_PER_SECOND:
                            log_info(f"[AntiDDoS] IP {client_ip} limit aştı, engelleniyor...")
                            self.server.blocked_ips.add(client_ip)
                            self.server.update_blocked_clients(client_ip)
                            self.client.close()
                            break

                        self.bytes_received_in_last_second = 0
                        self.last_packet_time = time.time()

                    if packet_id in packets:
                        message = packets[packet_id](self.client, self.player, data)
                        message.decode()
                        message.process()
                else:
                    break
        except Exception as e:
            log_info(f"[HATA] İstemci hata - {client_ip}: {e}")
        finally:
            self.client.close()
            connected_ips.discard(client_ip)
            log_info(f"[BİLGİ] IP {client_ip} kapatıldı")

if __name__ == "__main__":

    try:
        import importlib.util
        admin_bot_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "atesbot1v1.py.py")
        spec = importlib.util.spec_from_file_location("telebot_admin", admin_bot_path)
        admin_bot = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(admin_bot)

        def _run_admin_bot():
            try:
                admin_bot.run_bot()
            except Exception as e:
                log_info(f"TeleBot admin error: {e}")

        Thread(target=_run_admin_bot, daemon=True).start()
        log_info("TeleBot admin started")
    except Exception as e:
        log_info(f"TeleBot admin did not start: {e}")

    server = Server("0.0.0.0",9339)
    server.start()