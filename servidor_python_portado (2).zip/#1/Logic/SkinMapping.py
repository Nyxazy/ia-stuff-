import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKINS_TXT = ROOT / 'skins.txt'
ALT_SKINS_TXT = ROOT / 'uploads' / 'skins.txt'


def _path():
    if SKINS_TXT.exists():
        return SKINS_TXT
    if ALT_SKINS_TXT.exists():
        return ALT_SKINS_TXT
    return None


def get_skin_to_brawler_map():
    p = _path()
    mapping = {}
    if not p:
        return mapping
    current_brawler = None
    for raw in p.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = raw.strip()
        m_b = re.search(r'Айди бойца:\s*(\d+)', line)
        if m_b:
            current_brawler = int(m_b.group(1))
            continue
        m_s = re.match(r'^(\d+)\s*[-–]', line)
        if m_s and current_brawler is not None:
            mapping[int(m_s.group(1))] = current_brawler
    return mapping


def get_brawler_for_skin(skin_id):
    try:
        return get_skin_to_brawler_map().get(int(skin_id))
    except Exception:
        return None
