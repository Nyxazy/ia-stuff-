import json
import os
import sqlite3
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SUPP_PATH = ROOT / "JSON" / "supp.json"
DB_PATH = ROOT / "database" / "Player" / "plr.db"
_lock = threading.Lock()


def _ensure_file():
    SUPP_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not SUPP_PATH.exists():
        SUPP_PATH.write_text(json.dumps({"Creators": []}, ensure_ascii=False, indent=4), encoding="utf-8")


def load_data():
    _ensure_file()
    try:
        return json.loads(SUPP_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"Creators": []}


def save_data(data):
    _ensure_file()
    SUPP_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=4), encoding="utf-8")


def normalize_code(code):
    return (code or "").strip()


def find_creator(code):
    code = normalize_code(code)
    data = load_data()
    for creator in data.get("Creators", []):
        if str(creator.get("Code", "")) == code:
            return creator
    return None


def list_creators():
    return load_data().get("Creators", [])


def add_creator(code, low_id, reward_count=0):
    code = normalize_code(code)
    low_id = int(low_id)
    reward_count = int(reward_count)
    with _lock:
        data = load_data()
        creators = data.setdefault("Creators", [])
        for creator in creators:
            if str(creator.get("Code", "")) == code:
                creator["LowID"] = low_id
                creator["RewardCount"] = reward_count
                creator.setdefault("ActivationHistory", [])
                save_data(data)
                return creator
        creator = {
            "Code": code,
            "LowID": low_id,
            "RewardCount": reward_count,
            "ActivationHistory": []
        }
        creators.append(creator)
        save_data(data)
        return creator


def delete_creator(code):
    code = normalize_code(code)
    with _lock:
        data = load_data()
        creators = data.get("Creators", [])
        new_creators = [c for c in creators if str(c.get("Code", "")) != code]
        changed = len(new_creators) != len(creators)
        data["Creators"] = new_creators
        if changed:
            save_data(data)
        return changed


def activate_creator(player_low_id, code):
    code = normalize_code(code)
    with _lock:
        data = load_data()
        creators = data.get("Creators", [])
        target = None
        for creator in creators:
            if str(creator.get("Code", "")) == code:
                target = creator
                break
        if not target:
            return {"ok": False, "reason": "invalid_creator"}

        history = target.setdefault("ActivationHistory", [])
        already_used = int(player_low_id) in [int(x) for x in history]
        if not already_used:
            history.append(int(player_low_id))
            save_data(data)

        return {
            "ok": True,
            "reason": "creator_set",
            "code": code,
            "already_used": already_used,
        }
