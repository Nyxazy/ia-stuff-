import json
import sqlite3
import time
from pathlib import Path
from Logic.Notifications import add_notification_lowid
from Logic.PromoRewardSender import send_reward

ROOT = Path(__file__).resolve().parent.parent
PROMO_PATH = ROOT / "JSON" / "SecretCodes.json"
DB_PATH = ROOT / "database" / "Player" / "plr.db"


def _ensure_file():
    PROMO_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not PROMO_PATH.exists():
        PROMO_PATH.write_text(json.dumps({"Promocodes": []}, ensure_ascii=False, indent=4), encoding="utf-8")


def load_data():
    _ensure_file()
    try:
        return json.loads(PROMO_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"Promocodes": []}


def save_data(data):
    _ensure_file()
    PROMO_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=4), encoding="utf-8")


def normalize_code(code):
    return (code or "").strip()


def list_promos():
    return load_data().get("Promocodes", [])


def add_promo(code, item_type, amount=1, skin_id=0, brawler_id=0, extra=0, months=1, max_activations=1000, start_time=0, end_time=0):
    code = normalize_code(code)
    item_type = str(item_type)
    promo = {
        "Code": code,
        "MaxActivations": int(max_activations),
        "ActivationHistory": [],
        "StartTime": int(start_time or 0),
        "EndTime": int(end_time or 0),
        "Items": [
            {
                "Type": item_type,
                "Count": int(amount),
                "SkinID": int(skin_id),
                "BrawlerID": int(brawler_id),
                "Extra": int(extra),
                "Months": int(months),
            }
        ]
    }
    data = load_data()
    promos = data.setdefault("Promocodes", [])
    replaced = False
    for i, p in enumerate(promos):
        if str(p.get("Code", "")) == code:
            promos[i] = promo
            replaced = True
            break
    if not replaced:
        promos.append(promo)
    save_data(data)
    return promo


def delete_promo(code):
    code = normalize_code(code)
    data = load_data()
    promos = data.get("Promocodes", [])
    new_promos = [p for p in promos if str(p.get("Code", "")) != code]
    changed = len(new_promos) != len(promos)
    data["Promocodes"] = new_promos
    if changed:
        save_data(data)
    return changed


def find_promo(code):
    code = normalize_code(code)
    data = load_data()
    for promo in data.get("Promocodes", []):
        if str(promo.get("Code", "")) == code:
            return promo
    return None


def _is_time_valid(promo):
    now = int(time.time())
    start_time = int(promo.get("StartTime", 0) or 0)
    end_time = int(promo.get("EndTime", 0) or 0)
    if start_time and now < start_time:
        return False, "not_started"
    if end_time and now > end_time:
        return False, "expired"
    return True, "ok"


def _grant_item(low_id, item, client=None, player=None):
    item_type = str(item.get("Type", "")).lower()
    count = int(item.get("Count", 1) or 1)
    skin_id = int(item.get("SkinID", 0) or 0)
    brawler_id = int(item.get("BrawlerID", 0) or 0)
    months = int(item.get("Months", 1) or 1)
    extra = int(item.get("Extra", 0) or 0)

    if item_type == "premium":
        with sqlite3.connect(str(DB_PATH)) as conn:
            cur = conn.cursor()
            cur.execute("SELECT premiumLevel, premiumEndTime FROM plrs WHERE lowID=?", (int(low_id),))
            prow = cur.fetchone() or (0, 0)
            premium_level = int(prow[0] or 0)
            premium_end = int(prow[1] or 0)
            now = int(time.time())
            base = premium_end if premium_end > now else now
            new_end = base + months * 30 * 24 * 3600
            cur.execute("UPDATE plrs SET premiumLevel=?, premiumEndTime=? WHERE lowID=?", (max(1, premium_level), new_end, int(low_id)))
            conn.commit()
        try:
            add_notification_lowid(int(low_id), f"Promo reward: premium {months} month(s)", kind=81)
        except Exception:
            pass
        return True, "ok"

    if client is not None and player is not None:
        ok = send_reward(client, player, item_type, count=count, skin_id=skin_id, brawler_id=brawler_id, extra=extra)
        if ok:
            try:
                add_notification_lowid(int(low_id), f"Promo reward: {item_type} x{count}", kind=81)
            except Exception:
                pass
            return True, "ok"

    with sqlite3.connect(str(DB_PATH)) as conn:
        cur = conn.cursor()
        cur.execute("SELECT gold, gems, starpoints, brawlerData FROM plrs WHERE lowID=?", (int(low_id),))
        row = cur.fetchone()
        if not row:
            return False, "player_not_found"
        gold = int(row[0] or 0)
        gems = int(row[1] or 0)
        starpoints = int(row[2] or 0)
        try:
            brawler_data = json.loads(row[3])
        except Exception:
            brawler_data = {}

        if item_type == "coin":
            cur.execute("UPDATE plrs SET gold=? WHERE lowID=?", (gold + count, int(low_id)))
        elif item_type == "gems":
            cur.execute("UPDATE plrs SET gems=? WHERE lowID=?", (gems + count, int(low_id)))
        elif item_type == "starpoints":
            cur.execute("UPDATE plrs SET starpoints=? WHERE lowID=?", (starpoints + count, int(low_id)))
        elif item_type == "skin":
            unlocked = brawler_data.setdefault("UnlockedSkins", {})
            unlocked[str(skin_id)] = 1
            cur.execute("UPDATE plrs SET brawlerData=? WHERE lowID=?", (json.dumps(brawler_data, ensure_ascii=False), int(low_id)))
        elif item_type == "brawler":
            unlocked = brawler_data.setdefault("UnlockedBrawlers", {})
            unlocked[str(brawler_id)] = 1
            cur.execute("UPDATE plrs SET brawlerData=? WHERE lowID=?", (json.dumps(brawler_data, ensure_ascii=False), int(low_id)))
        elif item_type in ("megabox", "bigbox", "brawlbox", "box"):
            field = "bigbox" if item_type == "bigbox" else "box"
            cur.execute(f"SELECT {field} FROM plrs WHERE lowID=?", (int(low_id),))
            value = int((cur.fetchone() or [0])[0] or 0)
            cur.execute(f"UPDATE plrs SET {field}=? WHERE lowID=?", (value + count, int(low_id)))
        elif item_type == "thumbnail":
            cur.execute("UPDATE plrs SET profile_icon=? WHERE lowID=?", (extra, int(low_id)))
        else:
            return False, "unsupported_item_type"

        conn.commit()

    try:
        add_notification_lowid(int(low_id), f"Promo reward: {item_type} x{count}", kind=81)
    except Exception:
        pass
    return True, "ok"


def redeem_promo(low_id, code, client=None, player=None):
    code = normalize_code(code)
    data = load_data()
    promos = data.get("Promocodes", [])
    promo = None
    index = -1
    for i, p in enumerate(promos):
        if str(p.get("Code", "")) == code:
            promo = p
            index = i
            break
    if promo is None:
        return {"ok": False, "reason": "invalid_code"}

    ok, reason = _is_time_valid(promo)
    if not ok:
        return {"ok": False, "reason": reason}

    history = [int(x) for x in promo.get("ActivationHistory", [])]
    max_activations = int(promo.get("MaxActivations", -1) or -1)

    if max_activations == 0:
        return {"ok": False, "reason": "max_activations_reached"}
    if int(low_id) in history:
        return {"ok": False, "reason": "already_redeemed"}

    for item in promo.get("Items", []):
        granted, grant_reason = _grant_item(low_id, item, client=client, player=player)
        if not granted:
            return {"ok": False, "reason": grant_reason}

    history.append(int(low_id))
    promo["ActivationHistory"] = history
    if max_activations > 0:
        promo["MaxActivations"] = max_activations - 1
    promos[index] = promo
    data["Promocodes"] = promos
    save_data(data)
    return {"ok": True, "reason": "redeemed", "code": code, "promo": promo}
