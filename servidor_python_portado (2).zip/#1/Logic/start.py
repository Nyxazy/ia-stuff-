import telebot 
import random 
import json
import os
import sqlite3
import psutil
from core import Server
from Logic.Premium import grant_premium_lowid, revoke_premium_lowid, get_premium_by_lowid, format_utc, ensure_premium_columns

# создаем бота
admin=[6701969994]
man=[6701969994]
bot = telebot.TeleBot('7705985193:AAGJFQGc7lklPU9h2TTIVtqhsfBX3VUje8o')

def dball():
    conn = sqlite3.connect("database/Player/plr.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM plrs")
    return cur.fetchall()

# Путь к файлу config.json
config_file_path = 'config.json'

def load_config():
    try:
        with open(config_file_path, 'r', encoding='utf-8') as file:
            config = json.load(file)
        return config
    except (FileNotFoundError, json.JSONDecodeError):
        return None

def save_config(config):
    try:
        with open(config_file_path, 'w', encoding='utf-8') as file:
            json.dump(config, file, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Произошла ошибка: {e}")
        return False

def update_maintenance_status(new_status):
    config = load_config()
    if config:
        config['maintenance'] = new_status
        return save_config(config)
    return False

def is_admin(user_id):
    return user_id in admin


# Структура для скинов
skins = {
    "common": [29, 15, 2, 103, 109, 167, 27, 120, 139, 111, 137, 152,],  # ID скинов
    "rare": [25, 102, 58, 98, 28, 92, 158, 130, 88, 165, 93, 104, 132, 108, 45, 125, 117, 11, 126, 131, 20, 100],
    "epic": [52, 159, 79, 64, 44, 123, 163, 91, 57, 160, 99, 30, 128, 71, 59, 26, 68, 147, 50, 75, 96, 110, 101, 118],
    "legendary": [94, 49, 95]
}

# Привязка цен к редкостям
skin_prices = {
    "common": (30, 30),
    "rare": (80, 80),
    "epic": (150, 150),
    "legendary": (300, 300)
}

# Функция для получения списка всех акций из файла offers.json
def get_offers():
    # Читаем данные из файла offers.json
    with open("Logic/offers.json", "r",encoding='utf-8') as f:
        data = json.load(f)

    # Генерируем текстовый список всех акци
    offer_list = "Список акций:\n"
    for offer_id, offer_data in data.items():
        vault=offer_data['ShopType']
        daily=offer_data['ShopDisplay']
        current=""
        types=""
        if vault==1:current="Золото"
        elif vault==0:current="Кристаллы"
        if daily==1:types="Ежедневная"
        elif daily==0:types="Обычная"
        offer_list += f"\nАкция #{offer_id}\n"
        offer_list += f"Название: {offer_data['OfferTitle']}\n"
        offer_list += f"Тип: {types}\n"
        offer_list += f"Боец: {offer_data['BrawlerID'][0]}\n"
        offer_list += f"Скин: {offer_data['SkinID'][0]}\n"
        offer_list += f"Валюта: {current}\n"
        offer_list += f"Стоимость: {offer_data['Cost']}\n"
        offer_list += f"Множитель: {offer_data['Multiplier'][0]}\n"

    # Возвращаем текстовый список всех акций
    return offer_list
# Обработчик команды /list
@bot.message_handler(commands=['list'])
def handle_list_offers(message):
    # Получаем список всех акций из файла offers.json
    offer_list = get_offers()

    # Отправляем пользователю список всех акций
    bot.send_message(chat_id=message.chat.id, text=offer_list)
    
    
@bot.message_handler(commands=['new_offer'])
def add_offer(message):
    user_id = message.from_user.id
    if user_id in admin:
    	if len(message.text.split()) < 2:
    	   bot.reply_to(message, 'Используйте команду /new_offer с аргументами в формате: /new_offer <ID> <OfferTitle> <Cost> <Multiplier> <BrawlerID> <SkinID> <OfferBGR> <ShopType> <ShopDisplay>')
    	   return
    	offer_data = message.text.split()
    	new_offer = {
            'ID': [int(offer_data[1]), 0, 0],
            'OfferTitle': offer_data[2],
            'Cost': int(offer_data[3]),
            'OldCost': 0,
            'Multiplier': [int(offer_data[4]), 0, 0],
            'BrawlerID': [int(offer_data[5]), 0, 0],
            'SkinID': [int(offer_data[6]), 0, 0],
            'WhoBuyed': [],
            'Timer': 86400,
            'OfferBGR': offer_data[7],
            'ShopType': int(offer_data[8]),
            'ShopDisplay': int(offer_data[9])
    	}
    	with open('Logic/offers.json', 'r',encoding='utf-8') as f:
    	   offers = json.load(f)
    	offers[str(len(offers))] = new_offer
    	with open('Logic/offers.json', 'w',encoding='utf-8') as f:
    	   json.dump(offers, f, indent=4)
    	bot.reply_to(message, 'Новая акция добавлена!')
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
@bot.message_handler(commands=['panel_admin'])
def send_welcome(message):
    user_id = message.from_user.id
    if user_id in admin:
	    bot.reply_to(message, "Admin Panel:\n/status - server status\n/theme ID - change theme for everyone\n/new_code CODE - add creator code\n/del_code CODE - delete creator code\n/code_list - creator codes\n/premium ID [months] [level] - give Premium\n/del_premium ID - remove Premium\n/add_gems ID AMOUNT - set gems\n/ban ID - ban player\n/unban ID - unban player\n/clear_room - clear rooms\n/add_gold ID AMOUNT - set gold")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['panel_manager'])
def send_welcome(message):
    user_id = message.from_user.id
    if user_id in man:
	    bot.reply_to(message, "Manager Panel:\n/gems ID AMOUNT - set gems\n/prem ID [months] [level] - give Premium\n/del_prem ID - remove Premium")
    else:
        bot.reply_to(message, "Вы не являетесь менеджером")
@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Добро пожаловать в бота для выдачи ShinyBrawl!\n/panel_manager - Команда для выдачи менеджеров\n/panel_admin - Полный управления сервером")

@bot.message_handler(commands=['change_name'])
def change_name(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /change_name ID NAME")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET name = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} изменили имя на {ammount}.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['remove_offer'])
def remove_offer(message):
    user_id = message.from_user.id
    if user_id in admin:
    	if len(message.text.split()) != 2:
    	   bot.reply_to(message, 'Используйте команду /remove_offer с аргументом в формате: /remove_offer <ID>')
    	   return
    	offer_id = message.text.split()[1]
    	with open('Logic/offers.json', 'r', encoding='utf-8') as f:
    		offers = json.load(f)
    	if offer_id not in offers:
    		bot.reply_to(message, f'Акция с ID {offer_id} не найдена')
    		return
    	offers.pop(offer_id)
    	with open('Logic/offers.json', 'w', encoding='utf-8') as f:
    		json.dump(offers, f)
    	bot.reply_to(message, f'Акция с ID {offer_id} удалена')
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
# Определяем функцию-обработчик для команды /theme
@bot.message_handler(commands=['theme'])
def theme(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Выбери ID темы\n0 - Обычная\n1 - Новый год (Снег)\n2 - Красный новый год\n3 - От клеш рояля\n4 - Обычный фон с дефолт музыкой\n5 - Желтые панды\n7 - Роботы Зелёный фон\n8 - Хэллуин 2019\n9 - Пиратский фон (Новый год 2020)\n10 - Фон с обновы с мистером п.\n11 - Футбольный фон\n12 - Годовщина Supercell\n13 - Базар Тары\n14 - Лето с монстрами\nИспользовать команду /theme ID")
        else:
            user_id = message.from_user.id
            theme_id = message.text.split()[1]
            conn = sqlite3.connect("database/Player/plr.db")
            c = conn.cursor()
            c.execute(f"UPDATE plrs SET theme={theme_id}")
            conn.commit()
            c.execute("SELECT * FROM plrs")
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Айди всех записей был изменён на {theme_id}")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
#коды автора
@bot.message_handler(commands=['new_code'])
def new_code(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /new_code Название Кода(На англ)")
        else:
            code = message.text.split()[1]
            with open("config.json", "r", encoding='utf-8') as f:
                config = json.load(f)
            if code not in config["CCC"]:
                config["CCC"].append(code)
                with open("config.json", "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                bot.send_message(chat_id=message.chat.id, text=f"Новый код {code}, Был добавлен!")
            else:
                bot.send_message(chat_id=message.chat.id, text=f"Код {code} уже существует!")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['code_list'])
def code_list(message):
    with open('config.json', 'r') as f:
        data = json.load(f)
    code_list = '\n'.join(data["CCC"])
    bot.send_message(chat_id=message.chat.id, text=f"Список кодов: \n{code_list}")
    	
    	
@bot.message_handler(commands=['del_code'])
def del_code(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /del_code Название Кода")
        else:
            code = message.text.split()[1]
            with open("config.json", "r", encoding='utf-8') as f:
                config = json.load(f)
            if code in config["CCC"]:
                config["CCC"].remove(code)
                with open("config.json", "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                bot.send_message(chat_id=message.chat.id, text=f"Код {code}, Был удалён!")
            else:
                bot.send_message(chat_id=message.chat.id, text=f"Код {code} не найден!")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
 #конец кодов

def _parse_premium_args(message):
    parts = message.text.split()
    if len(parts) < 2:
        return None, None, None
    lowid = int(parts[1])
    months = int(parts[2]) if len(parts) >= 3 else 1
    level = int(parts[3]) if len(parts) >= 4 else 1
    months = max(1, months)
    level = max(1, min(level, 3))
    return lowid, months, level


@bot.message_handler(commands=['premium', 'prem', 'add_premium', 'add_vip'])
def add_premium(message):
    user_id = message.from_user.id
    if user_id in admin or user_id in man:
        try:
            parsed = _parse_premium_args(message)
            if parsed[0] is None:
                bot.reply_to(message, "Correct usage: /premium ID [months] [level 1-3]")
                return
            lowid, months, level = parsed
            ensure_premium_columns()
            end_time = grant_premium_lowid(lowid, months=months, level=level)
            bot.send_message(
                chat_id=message.chat.id,
                text=f"Premium activated/extended for ID {lowid}\nLevel: {level}\nMonths added: {months}\nExpires at: {format_utc(end_time)}"
            )
        except Exception as e:
            bot.reply_to(message, f"Error activating Premium: {e}")
    else:
        bot.reply_to(message, "You do not have permission!")


@bot.message_handler(commands=['del_premium', 'remove_premium', 'del_prem', 'del_vip'])
def del_premium(message):
    user_id = message.from_user.id
    if user_id in admin or user_id in man:
        try:
            parts = message.text.split()
            if len(parts) < 2:
                bot.reply_to(message, "Correct usage: /del_premium ID")
                return
            lowid = int(parts[1])
            ensure_premium_columns()
            revoke_premium_lowid(lowid)
            bot.send_message(chat_id=message.chat.id, text=f"Premium removed from ID {lowid}")
        except Exception as e:
            bot.reply_to(message, f"Error removing Premium: {e}")
    else:
        bot.reply_to(message, "You do not have permission!")


@bot.message_handler(commands=['premium_info'])
def premium_info(message):
    user_id = message.from_user.id
    if user_id in admin or user_id in man:
        try:
            parts = message.text.split()
            if len(parts) < 2:
                bot.reply_to(message, "Correct usage: /premium_info ID")
                return
            lowid = int(parts[1])
            ensure_premium_columns()
            level, end_time, notice = get_premium_by_lowid(lowid)
            active = level > 0 and end_time > __import__('time').time()
            bot.reply_to(message, f"ID {lowid}\nPremium active: {active}\nLevel: {level}\nExpires at: {format_utc(end_time)}")
        except Exception as e:
            bot.reply_to(message, f"Error: {e}")
    else:
        bot.reply_to(message, "You do not have permission!")

@bot.message_handler(commands=['add_gems'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /add_gems ID AMMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET gems = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} Выдали {ammount} Гемов")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['gems'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in man:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /gems ID AMMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET gems = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} Выдали {ammount} Гемов")
    else:
        bot.reply_to(message, "Вы не являетесь менеджером!")
		
@bot.message_handler(commands=['ban'])
def ban(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /ban ID")
        else:
            vip_id = int(message.text.split()[1])
            with open("config.json", "r", encoding='utf-8') as f:
                config = json.load(f)
            if vip_id not in config["banID"]:
                config["banID"].append(vip_id)
                with open("config.json", "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                bot.send_message(chat_id=message.chat.id, text=f"Бан был выдан игроку {vip_id}")
            else:
                bot.send_message(chat_id=message.chat.id, text=f"Бан уже есть у игрока {vip_id}")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['unban'])
def ban(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /unban ID")
        else:
            vip_id = int(message.text.split()[1])
            with open("config.json", "r", encoding='utf-8') as f:
                config = json.load(f)
            if vip_id in config["banID"]:
                config["banID"].remove(vip_id)
                with open("config.json", "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                bot.send_message(chat_id=message.chat.id, text=f"Разбан был выдан игроку {vip_id}")
            else:
                bot.send_message(chat_id=message.chat.id, text=f"У игрока {vip_id} отсутствует бан")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['clear_room'])
def clear_room(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            user_id = message.from_user.id
            plrsinfo = "database/Player/plr.db"
            if os.path.exists(plrsinfo):
                conn = sqlite3.connect("database/Player/plr.db")
                c = conn.cursor()
                c.execute("UPDATE plrs SET roomID=0")
                c.execute("SELECT * FROM plrs")
                conn.commit()
                conn.close()
                bot.reply_to(message, 'Команды были очищены!')
            else:
                bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['add_trophies'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /add_trophies ID AMMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET trophies = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} Выдали {ammount} Трофеев")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['add_gold'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /add_gold ID AMMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET gold = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} Выдали {ammount} Монет!")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

# Команда для обновления значения maintenance на true
@bot.message_handler(commands=['enable_maintenance'])
def enable_maintenance(message):
    if is_admin(message.from_user.id):
        if update_maintenance_status(True):
            bot.reply_to(message, "Технический перерыв был включен!")
        else:
            bot.reply_to(message, "Произошла ошибка при включении технического перерыва.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

# Команда для обновления значения maintenance на false
@bot.message_handler(commands=['disable_maintenance'])
def disable_maintenance(message):
    if is_admin(message.from_user.id):
        if update_maintenance_status(False):
            bot.reply_to(message, "Технический перерыв был выключен!")
        else:
            bot.reply_to(message, "Произошла ошибка при выключении технического перерыва.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['status'])
def status(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            user_id = message.from_user.id
            with open('config.json', 'r') as f:
                data = json.load(f)
                ban_list = len(data["banID"])
                ensure_premium_columns()
                conn_p = sqlite3.connect("database/Player/plr.db")
                cur_p = conn_p.cursor()
                cur_p.execute("SELECT COUNT(*) FROM plrs WHERE premiumLevel > 0 AND premiumEndTime > strftime('%s','now')")
                vip_list = cur_p.fetchone()[0]
                conn_p.close()
            player_list = len(dball())
            bot.reply_to(message, f'Всего создано аккаунтов: {player_list}\nИгроков в бане: {ban_list}\nPlayers with Premium: {vip_list}\n\nRAM: {psutil.virtual_memory().percent}%\nCPU: {psutil.cpu_percent()}%')
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

# Запускаем бота
bot.polling()
