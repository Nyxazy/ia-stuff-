from database.DataBase import DataBase
from Utils.Reader import BSMessageReader
from Logic.Notifications import NotificationFactory
from Logic.MCbyLkPrtctrd.MilestonesClaimSupplyByLkPrtctrd import MilestonesClaimSupplyByLkPrtctrd


class LogicViewNotificationCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes, id, k, bp, id2=0):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.a = self.read_Vint()
        self.b = self.read_Vint()
        self.c = self.read_Vint()
        self.d = self.read_Vint()
        self.notification_index = self.read_Vint()

    def process(self):
        factory = NotificationFactory.load(self.player.low_id)
        notification = factory.get(self.notification_index)
        if notification is None:
            return
        if notification.IsViewed:
            return
        if notification.Id == 79:
            gained = sum(int(x or 0) for x in notification.StarpointsAwarded)
            if gained > 0:
                self.player.starpoints += gained
                DataBase.replaceValue(self, 'starpoints', self.player.starpoints)
        elif notification.Id == 89:
            if notification.DonationCount > 0:
                MilestonesClaimSupplyByLkPrtctrd(self.client, self.player, "BPLkPrtctrd", {"Character": [0, 0], "Skin": [0, 0], "Type": 8, "Amount": notification.DonationCount, "Road": 0, "Season": 0, "Level": -2}).send()
            if notification.GoldCount > 0:
                MilestonesClaimSupplyByLkPrtctrd(self.client, self.player, "BPLkPrtctrd", {"Character": [0, 0], "Skin": [0, 0], "Type": 7, "Amount": notification.GoldCount, "Road": 0, "Season": 0, "Level": -2}).send()
        notification.IsViewed = True
        factory.save(self.player.low_id)
