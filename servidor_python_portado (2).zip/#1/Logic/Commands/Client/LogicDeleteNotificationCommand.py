from Utils.Reader import BSMessageReader
from Logic.Notifications import NotificationFactory


class LogicDeleteNotificationCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes=None):
        super().__init__(initial_bytes or b'')
        self.player = player
        self.client = client

    def decode(self):
        self.a = self.read_Vint()
        self.b = self.read_Vint()
        self.c = self.read_Vint()
        self.d = self.read_Vint()
        self.notification_index = self.read_Vint()

    def process(self):
        factory = NotificationFactory.load(self.player.low_id)
        if factory.remove(self.notification_index):
            factory.save(self.player.low_id)
