from Logic.Shop import Shop
from Utils.Writer import Writer


class LogicOffersChangedCommand(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.player = player
        self.id = 24111

    def encode(self):
        self.writeVint(211)
        Shop.EncodeShopOffers(self)

    def process(self):
        Shop.MarkAllOffersViewed(self)
