from Logic.LogicBuy import LogicBuy
from Logic.MCbyLkPrtctrd.MilestonesClaimSupplyByLkPrtctrd import MilestonesClaimSupplyByLkPrtctrd as Supply
from database.DataBase import DataBase
from Logic.SkinMapping import get_brawler_for_skin


def _replace(player, key, value):
    db = DataBase()
    db.player = player
    db.replaceValue(key, value)


def send_reward(client, player, item_type, count=1, skin_id=0, brawler_id=0, extra=0):
    item_type = str(item_type or '').lower()
    count = int(count or 1)
    skin_id = int(skin_id or 0)
    brawler_id = int(brawler_id or 0)
    extra = int(extra or 0)

    if item_type == 'coin':
        LogicBuy(client, player, 1, 0, 0, count, 0, 0, 0, 0, 0, 0, 0, 0).send()
        return True
    if item_type == 'gems':
        LogicBuy(client, player, 2, 0, 0, count, 0, 0, 0, 0, 0, 0, 0, 0).send()
        return True
    if item_type == 'skin':
        inferred_brawler = get_brawler_for_skin(skin_id)
        if inferred_brawler is not None and int(player.UnlockedBrawlers.get(str(inferred_brawler), 0) or 0) != 1:
            player.UnlockedBrawlers[str(inferred_brawler)] = 1
            _replace(player, 'UnlockedBrawlers', player.UnlockedBrawlers)
            LogicBuy(client, player, 6, 0, 0, 1, 0, 0, inferred_brawler, 0, 0, 0, 0, 0).send()
        player.UnlockedSkins[str(skin_id)] = 1
        _replace(player, 'UnlockedSkins', player.UnlockedSkins)
        LogicBuy(client, player, 7, 0, 0, 1, 0, 0, 0, 0, 0, skin_id, 0, 0).send()
        return True
    if item_type == 'brawler':
        player.UnlockedBrawlers[str(brawler_id)] = 1
        _replace(player, 'UnlockedBrawlers', player.UnlockedBrawlers)
        LogicBuy(client, player, 6, 0, 0, 1, 0, 0, brawler_id, 0, 0, 0, 0, 0).send()
        return True
    if item_type == 'starpoints':
        player.starpoints += count
        _replace(player, 'starpoints', player.starpoints)
        return True
    if item_type == 'powerpoints':
        if brawler_id <= 0:
            return False
        current_points = int(player.brawlerPoints.get(str(brawler_id), 0) or 0)
        player.brawlerPoints[str(brawler_id)] = min(current_points + count, 1410)
        _replace(player, 'brawlerPoints', player.brawlerPoints)
        LogicBuy(client, player, 5, 0, 0, count, 0, 0, brawler_id, 0, 0, 0, 0, 0).send()
        return True
    if item_type in ('megabox', 'bigbox', 'brawlbox', 'box'):
        box_map = {
            'box': 10,
            'brawlbox': 10,
            'megabox': 11,
            'bigbox': 12,
        }
        for _ in range(max(1, count)):
            Supply(client, player, 'BOXLkPrtctrd', {'BoxDID': box_map[item_type]}).send()
        return True
    if item_type == 'thumbnail':
        player.profile_icon = extra
        _replace(player, 'profile_icon', player.profile_icon)
        return True
    return False
