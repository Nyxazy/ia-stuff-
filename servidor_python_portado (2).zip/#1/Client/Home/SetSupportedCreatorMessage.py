from Utils.Reader import BSMessageReader
from database.DataBase import DataBase
from Server.Home.SetSupportedCreatorReponse import SetSupportedCreatorReponse
from Logic.Commands.Server.AvailableServerCommandMessage import AvailableServerCommandMessage
from Logic.PromoCodes import redeem_promo, find_promo, normalize_code as normalize_promo_code
from Logic.Creators import activate_creator, find_creator, normalize_code as normalize_creator_code
import json

class SetSupportedCreatorMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.ccc = self.read_string()

    def process(self):
        raw_code = self.player.ccc or ''
        code = normalize_promo_code(raw_code)

        if code == '':
            self.player.ccc = ''
            DataBase.replaceValue(self, 'SCC', self.player.ccc)
            AvailableServerCommandMessage(self.client, self.player, 215).send()
            return

        promo = find_promo(code)
        if promo is not None:
            result = redeem_promo(int(self.player.low_id), code, client=self.client, player=self.player)
            self.player.ccc = ''
            DataBase.replaceValue(self, 'SCC', self.player.ccc)
            if result.get('ok'):
                AvailableServerCommandMessage(self.client, self.player, 215).send()
            else:
                SetSupportedCreatorReponse(self.client, self.player).send()
            return

        creator = find_creator(normalize_creator_code(code))
        if creator is not None:
            self.player.ccc = code
            DataBase.replaceValue(self, 'SCC', self.player.ccc)
            activate_creator(int(self.player.low_id), code)
            AvailableServerCommandMessage(self.client, self.player, 215).send()
            return

        config = open('config.json', 'r')
        content = config.read()
        settings = json.loads(content)
        if self.player.ccc in settings.get('CCC', []):
            DataBase.replaceValue(self, 'SCC', self.player.ccc)
            AvailableServerCommandMessage(self.client, self.player, 215).send()
        else:
            SetSupportedCreatorReponse(self.client, self.player).send()