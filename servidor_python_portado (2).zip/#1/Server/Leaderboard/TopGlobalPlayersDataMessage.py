from Utils.Writer import Writer
from database.DataBase import DataBase
import time
class TopGlobalPlayersDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24403
        self.player = player

    def encode(self):
        self.writeBoolean(True)
        self.writeVint(0)
        self.writeVint(0)
        self.writeString()

        fetch = DataBase.getLeaders(self)
        x=1
        self.writeVint(len(fetch))                

        for i in fetch:
            if i[0] == self.player.low_id:
                x = fetch.index(i)+1
            self.writeVint(0)          
            self.writeVint(i[0])         

            self.writeVint(1)
            self.writeVint(i[2])                  

            self.writeVint(1)

            self.writeString()       

            premium_active = i[6] > 0 and i[7] > time.time()
            self.writeString(f"[ VIP ] ( {i[1]} )" if premium_active else i[1])              

            self.writeVint(1)               
            self.writeVint(28000000 + i[3])
            self.writeVint(43000000 + i[4])
            self.writeVint(43000000 + i[4] if premium_active else 0)

            self.writeVint(0)


        self.writeVint(0)
        self.writeVint(x)
        self.writeVint(0)
        self.writeVint(0)

        self.writeString(self.player.Region)
