from Utils.Writer import Writer
from database.DataBase import DataBase
import random
from Logic.Premium import premium_level, premium_trophy_bonus, premium_high_name_color, premium_display_name
import sys
import os
from .settings import set_double_trophies, set_double_tokens, get_double_trophies, get_double_tokens
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class BattleResult2Message(Writer):
    def __init__(self, client, player, result):
        super().__init__(client)
        self.id = 23456
        self.player = player
        self.result = result

    def encode(self):
        brawler_trophies = self.player.brawlers_trophies[str(self.player.brawler_id)]
        win_val = 0
        lose_val = 0
        tokenGained = 0
        tropGained = 0
        if 0 <= brawler_trophies <= 49:
            win_val = 1250
            lose_val = 0
        else:
            if 50 <= brawler_trophies <= 99:
                win_val = 30
                lose_val = -1
            if 100 <= brawler_trophies <= 199:
                win_val = 30
                lose_val = -2
            if 200 <= brawler_trophies <= 299:
                win_val = 30
                lose_val = -3
            if 300 <= brawler_trophies <= 399:
                win_val = 30
                lose_val = -4
            if 400 <= brawler_trophies <= 499:
                win_val = 30
                lose_val = -5
            if 500 <= brawler_trophies <= 599:
                win_val = 30
                lose_val = -6
            if 600 <= brawler_trophies <= 699:
                win_val = 30
                lose_val = -7
            if 700 <= brawler_trophies <= 799:
                win_val = 30
                lose_val = -8
            if 800 <= brawler_trophies <= 899:
                win_val = 15
                lose_val = -9
            if 900 <= brawler_trophies <= 999:
                win_val = 15
                lose_val = -10
            if 1000 <= brawler_trophies <= 1099:
                win_val = 15
                lose_val = -11
            if 1100 <= brawler_trophies <= 1199:
                win_val = 15
                lose_val = -12
            if 1200 <= brawler_trophies <= 1250:
                win_val = 15
                lose_val = -10
            if 1251 <= brawler_trophies:
                win_val = 15
                lose_val = -10
        if self.player.battle_result == 1:
            tropGained = lose_val
            tokenGained = 10
        elif self.player.battle_result == 0:
            tropGained = win_val
            tokenGained = 20
            
        self.writeVint(1)                        
        self.writeVint(self.player.battle_result)          

        premium_lvl = premium_level(player=self.player)
        premium_bonus = premium_trophy_bonus(tropGained, premium_lvl)
        tropGained += premium_bonus

        self.writeVint(tokenGained)                
        self.writeVint(tropGained)                  
        self.writeVint(0)                               
        self.writeVint(0)                                               
        self.writeVint(0)                     
        self.writeVint(0)                          
        self.writeVint(0)                            
        self.writeVint(0)                                 
        self.writeVint(0)                            
        self.writeVint(0)                                                           
        self.writeVint(0)                           
        self.writeVint(0)                           
        self.writeVint(0)                              
        self.writeVint(0)                    
        self.writeVint(premium_bonus)
        self.writeVint(16)                                                                
        self.writeVint(-64)                              
        self.writeVint(0)                                       
            
                       
        self.writeVint(6)                            
        
        self.writeVint(1)                            
        self.writeScId(16, self.player.brawler_id)                 
        self.writeScId(29, self.player.skin_id)              
        self.writeVint(self.player.brawlers_trophies[str(self.player.brawler_id)])                        
        self.writeVint(0)                               
        self.writeVint(self.player.brawlerPowerLevel[str(self.player.brawler_id)])                           
        self.writeBoolean(True)                         
        self.writeInt(0)         
        self.writeInt(self.player.low_id)        
        self.writeString(premium_display_name(self.player.name, player=self.player))            
        self.writeVint(100)                          
        self.writeVint(28000000 + self.player.profile_icon)                      
        self.writeVint(43000000 + self.player.name_color)                    
        self.writeVint(premium_high_name_color(self.player.name_color, player=self.player))
            
        self.writeVint(0)                            
        self.writeScId(16, self.player.bot1)                
        self.writeVint(0)             
        self.writeVint(0)                   
        self.writeVint(0)                               
        self.writeVint(1)                      
        self.writeBoolean(False)                         
        self.writeString("Appel brawl")             
        self.writeVint(0)                          
        self.writeVint(28000000)                      
        self.writeVint(43000000)                    
        self.writeVint(43000000)                    
            
        self.writeVint(0)                            
        self.writeScId(16, self.player.bot2)                
        self.writeVint(0)             
        self.writeVint(0)                   
        self.writeVint(0)                               
        self.writeVint(1)                      
        self.writeBoolean(False)                         
        self.writeString("Appel brawl")             
        self.writeVint(0)                          
        self.writeVint(28000000)                      
        self.writeVint(43000000)                    
        self.writeVint(43000000)                    

        self.writeVint(2)                            
        self.writeScId(16, self.player.bot3)                
        self.writeVint(0)             
        self.writeVint(0)                   
        self.writeVint(0)                               
        self.writeVint(1)                      
        self.writeBoolean(False)                         
        self.writeString("Appel brael")             
        self.writeVint(0)                          
        self.writeVint(28000000)                      
        self.writeVint(43000000)                    
        self.writeVint(43000000)                    

        self.writeVint(2)                            
        self.writeScId(16, self.player.bot4)                
        self.writeVint(0)             
        self.writeVint(0)                   
        self.writeVint(0)                               
        self.writeVint(1)                      
        self.writeBoolean(False)                         
        self.writeString("Меня ебут")             
        self.writeVint(0)                          
        self.writeVint(28000000)                      
        self.writeVint(43000000)                    
        self.writeVint(43000000)                    

        self.writeVint(2)                            
        self.writeScId(16, self.player.bot5)                
        self.writeVint(0)             
        self.writeVint(0)                   
        self.writeVint(0)                               
        self.writeVint(1)                      
        self.writeBoolean(False)                         
        self.writeString("https://t.me/v43_Brwwloweeen")             
        self.writeVint(0)                          
        self.writeVint(28000000)                      
        self.writeVint(43000000)                    
        self.writeVint(43000000)                    
                          
        self.writeVint(2)        
        self.writeVint(0)                       
        self.writeVint(0)                           
        self.writeVint(8)                            
        self.writeVint(0)                                

                                          
        self.writeVint(0)        

                                            
        self.writeVint(2)        
        self.writeVint(1)                            
        self.writeVint(self.player.brawlers_trophies[str(self.player.brawler_id)])                   
        self.writeVint(self.player.brawlers_trophies[str(self.player.brawler_id)])                            
        self.writeVint(5)                              
        self.writeVint(10)                    
        self.writeVint(0)                              
        
        self.writeScId(28, 0)                                           
        self.writeBoolean(False)              
        if self.player.name != "VBC26":
            self.player.bet = tropGained
            self.player.betTok = tokenGained
            self.player.brawlers_trophies[str(self.player.brawler_id)] += self.player.bet
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            self.player.BPTOKEN = self.player.BPTOKEN + tokenGained
            DataBase.replaceValue(self, 'BPTOKEN', self.player.BPTOKEN)
            self.player.trioWINS = self.player.trioWINS + 1
            DataBase.replaceValue(self, 'trioWINS', self.player.trioWINS)
            self.player.player_experience += 10
            DataBase.replaceValue(self, 'playerExp', self.player.player_experience)
