import os
import Configuration
from Classes.ServerConnection import ServerConnection
from Static.StaticData import StaticData

if not os.path.exists(f"HexDumpV{Configuration.settings['DumpMajor']}"):
    os.mkdir(f"HexDumpV{Configuration.settings['DumpMajor']}")

StaticData.Preload()

print("""    ____  __________  _____
   / __ \/ ____/ __ \/ ___/
  / /_/ / /_  / /_/ /\__ \ 
 / ____/ __/ / ____/___/ / 
/_/   /_/   /_/    /____/  
                           """)

ServerConnection(("0.0.0.0", 9347))