from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Packets.PiranhaMessage import PiranhaMessage


class SetCountryMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["CountryID"] = self.readDataReference()[1]
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        playerData = db_instance.getPlayer(calling_instance.player.ID)
        if fields["CountryID"] == 0:
          playerData["Region"] = "_EU"
          calling_instance.player.RegionRefID = 0
        if fields["CountryID"] == 9:
          playerData["Region"] = "US"
          calling_instance.player.RegionRefID = 9
        if fields["CountryID"] == 7:
          playerData["isPlayerAgeSet"] = 1
          fields["Socket"] = calling_instance.client
          Messaging.sendMessage(20132, fields)
        db_instance.updatePlayerData(playerData, calling_instance)
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(24178, fields, calling_instance.player)
        pass

    def getMessageType(self):
        return 12998

    def getMessageVersion(self):
        return self.messageVersion