from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Packets.PiranhaMessage import PiranhaMessage


class SetInvitesBlockedMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        self.writeBoolean(fields["Bool"])
        pass

    def decode(self):
        fields = {}
        fields["Bool"] = self.readBoolean()
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        playerData = db_instance.getPlayer(calling_instance.player.ID)
        #playerData["isDND"] = fields["Val"]
        fields["Socket"] = calling_instance.client
        #fields["Command"] = {"ID": 213}
        db_instance.updatePlayerData(playerData, calling_instance)
        #Messaging.sendMessage(24111, fields)
        
        pass

    def getMessageType(self):
        return 14777

    def getMessageVersion(self):
        return self.messageVersion