from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Packets.PiranhaMessage import PiranhaMessage


class CreatePlayerMapMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        self.writeString(fields["MapString"])
        self.writeVInt(fields["Int"])
        self.writeDataReference(fields["Ref"])
        pass

    def decode(self):
        fields = {}
        fields["MapString"] = self.readString()
        fields["Int"] = self.readVInt()
        fields["Ref"] = self.readDataReference()[1]
        print(fields["Ref"])
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        #db_instance = DatabaseHandler()
        #playerData = db_instance.getPlayer(calling_instance.player.ID)
        calling_instance.player.MapRef = fields["Ref"]    #db_instance.updatePlayerData(playerData, calling_instance)
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(22100, fields, calling_instance.player)
        Messaging.sendMessage(12107, fields, calling_instance.player)
        pass

    def getMessageType(self):
        return 12100

    def getMessageVersion(self):
        return self.messageVersion