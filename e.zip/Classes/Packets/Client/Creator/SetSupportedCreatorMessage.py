from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Static.jsonhelper import jsonhelper


class SetSupportedCreatorMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Code"] = self.readString()
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        playerData = db_instance.getPlayer(calling_instance.player.ID)
        getcode = jsonhelper.getvar("Static/codes.json","Codes")
        if fields["Code"] in getcode:
          playerData["ContentCreator"] = fields["Code"]
          fields["Socket"] = calling_instance.client
          fields["Command"] = {"ID": 215}
          Messaging.sendMessage(24111, fields)
          Messaging.sendMessage(28686, fields, calling_instance.player)
          db_instance.updatePlayerData(playerData, calling_instance)
        if fields["Code"] not in getcode:
          fields["Socket"] = calling_instance.client
          Messaging.sendMessage(28686, fields, calling_instance.player)
        pass

    def getMessageType(self):
        return 18686

    def getMessageVersion(self):
        return self.messageVersion