from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Messaging import Messaging


class SetSupportedCreatorResponseMessage(PiranhaMessage):


    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0


    def encode(self, fields, player):
        self.writeVInt(1)
        self.writeString("hi")
        pass


    def decode(self):
        fields = {}
        super().decode(fields)
        return fields


    def execute(message, calling_instance, fields):
        pass


    def getMessageType(self):
        return 28686


    def getMessageVersion(self):
        return self.messageVersion
