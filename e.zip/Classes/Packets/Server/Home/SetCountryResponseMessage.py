from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Messaging import Messaging


class SetCountryResponseMessage(PiranhaMessage):


    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0


    def encode(self, fields, player):
        self.writeVInt(0)
        self.writeDataReference(14, player.RegionRefID)
        pass


    def decode(self):
        fields = {}
        super().decode(fields)
        return fields


    def execute(message, calling_instance, fields):
        pass


    def getMessageType(self):
        return 24178


    def getMessageVersion(self):
        return self.messageVersion
