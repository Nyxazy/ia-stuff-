import time

from Classes.ByteStreamHelper import ByteStreamHelper
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Static.StaticData import StaticData
import Configuration
import random

class OwnHomeDataMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        ownedBrawlersCount = len(player.OwnedBrawlers)
        ownedPinsCount = len(player.OwnedPins)
        ownedThumbnailCount = len(player.OwnedThumbnails)
        ownedSkins = []

        for brawlerInfo in player.OwnedBrawlers.values():
            try:
                ownedSkins.extend(brawlerInfo["Skins"])
            except KeyError:
                continue

        self.writeVInt(int(time.time()))
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(player.Trophies) # Trophies
        self.writeVInt(player.HighestTrophies) # Highest Trophies
        self.writeVInt(player.HighestTrophies)
        self.writeVInt(player.TrophyRoadTier)
        self.writeVInt(player.Experience + 99999) # Experience
        self.writeDataReference(28, player.Thumbnail) # Thumbnail
        self.writeDataReference(43, player.Namecolor) # Namecolor

        self.writeVInt(0) # PlayedGameModesArray

        try:
        	player.BrawlersSelectedSkins
        except KeyError:
        	player.BrawlersSelectedSkins = {}
        self.writeVInt(len(player.BrawlersSelectedSkins)) # Selected Skins
        for brawlerID in player.BrawlersSelectedSkins:
        	skinID = player.BrawlersSelectedSkins[brawlerID]
        	self.writeDataReference(29, skinID)

        self.writeVInt(0) # Randomizer Skin Selected

        self.writeVInt(0) # Current Random Skin

        self.writeVInt(len(ownedSkins))

        for skinID in ownedSkins:
            self.writeDataReference(29, skinID)

        self.writeVInt(0) # Unlocked Skin Purchase Option

        self.writeVInt(0) # New Item State

        self.writeVInt(0) # Leaderboard Region
        self.writeVInt(player.HighestTrophies)
        self.writeVInt(0) # Tokens Used in Battles
        self.writeVInt(1) # Control Mode
        self.writeBoolean(True) # Battle Hints?
        self.writeVInt(player.TokensDoubler)
        self.writeVInt(999999) # Trophy Road Timer
        self.writeVInt(999999) # Power Play Timer(Don't work')
        self.writeVInt(999999) # Brawl Pass Timer

        self.writeVInt(999)
        self.writeVInt(999)

        self.writeVInt(5)

        self.writeVInt(999)
        self.writeVInt(999)
        self.writeVInt(999)
        self.writeVInt(999)
        self.writeVInt(999)

        self.writeBoolean(False) # Offer 1
        self.writeBoolean(False) # Offer 2
        self.writeBoolean(True) # Token Doubler Enabled
        self.writeVInt(2)  # Token Doubler New Tag State
        self.writeVInt(2)  # Event Tickets New Tag State
        self.writeVInt(2)  # Coin Packs New Tag State
        self.writeVInt(0)  # Change Name Cost
        self.writeVInt(0)  # Timer For the Next Name Change

        '''
        0: FREE BOX
        1: COINS
        2: RANDOM BRAWLER RARITY
        3: BRAWLER
        4: SKIN
        5: ?
        6: BRAWL BOX
        7: TICKETS
        8: POWER POINTS
        9: TOKEN DOUBLER
        10: MEGA BOX
        11: ?
        12: POWER POINTS
        13: NEW EVENT SLOT
        14: BIG BOX
        15: BRAWL BOX
        16: GEMS
        17: STAR POINTS
        18: QUEST???
        19: PIN
        20: SET OF PINS
        21: PIN PACK
        22: PIN PACK FOR
        23: PIN OF RARITY
        24: ?
        25: ?
        26: ?
        27: PIN PACK OF RARITY
        28: ?
        29: ?
        30: NEW BRAWLER UPGRADED TO LEVEL
        31: RANDOM BRAWLER OF RARITY UPGRADED TO LEVEL
        32: GEAR TOKENS
        33: SCRAP
        '''

        ShopData = StaticData.ShopData

        self.writeVInt(len(ShopData["Offers"]) + len(player.DailyOffers)) # Offers count

        for i in ShopData["Offers"]:
            def checkAvailability():
            	results = []
            	result = False
            	for reward in i["Rewards"]:
            		if reward["ItemType"] == 4:
            			if reward["Extra"] in ownedSkins:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            			if str(reward["BrawlerID"][1]) not in list(player.OwnedBrawlers.keys()):
            				midresult = False
            				for x in i["Rewards"]:
            					if x["ItemType"] == 3:
            						midresult = True
            				if midresult != True:
            					if len(i["Rewards"]) > 1:
            						results.append(True)
            					else:
            						result = True
            		if reward["ItemType"] == 3 or reward["ItemType"] == 30:
            			if str(reward["BrawlerID"][1]) in list(player.OwnedBrawlers.keys()):
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 19:
            			if reward["Extra"] in player.OwnedPins:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 25:
            			if reward["Extra"] in player.OwnedThumbnails:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            	if i["Rewards"].index(reward) == len(i["Rewards"]) -1:
            		if True in results:
            			result = True
            	return result
            self.writeVInt(len(i["Rewards"]))  # RewardCount
            for reward in i["Rewards"]:
                self.writeVInt(reward["ItemType"]) # ItemType
                self.writeVInt(reward["Amount"])
                if reward["BrawlerID"][0] != 0:
                    self.writeDataReference(reward["BrawlerID"][0], reward["BrawlerID"][1]) # CsvID
                else:
                    self.writeDataReference(0)
                self.writeVInt(reward["Extra"])

            self.writeVInt(i["Currency"])
            self.writeVInt(i["Cost"])
            self.writeVInt(i["Time"])
            self.writeVInt(0) # State
            self.writeVInt(0)
            if i["OfferID"] in player.PushasedOffers or checkAvailability() == True:
            	self.writeBoolean(True) # Claim
            else:
            	self.writeBoolean(i['Claim']) # Claim
            self.writeVInt(ShopData["Offers"].index(i)) # Offer Index
            self.writeVInt(0)
            self.writeBoolean(i["DailyOffer"])
            self.writeVInt(i["OldPrice"])
            if "TID" in i["Text"]:
            	self.writeInt(1)
            elif i["Text"] == "None":
            	self.writeInt(2)
            else:
            	self.writeInt(0)
            if i["Text"] == "None":
                self.writeString()
            else:
                self.writeString(i["Text"])
            self.writeBoolean(False)
            if i["Background"] == "None":
                self.writeString()
            else:
                self.writeString(i["Background"])
            self.writeVInt(-1)
            self.writeBoolean(i["Processed"])
            self.writeVInt(i["TypeBenefit"])
            self.writeVInt(i["Benefit"])
            self.writeString()
            self.writeBoolean(i["OneTimeOffer"])
            self.writeBoolean(False) # Unk
            if i["BigOffer"] == True:
            	if i["ShopPanelLayouts"] != -1:
            		self.writeDataReference(69, i["ShopPanelLayouts"]) # For Big Offers
            	else:
            		self.writeDataReference(0, 0) # For Big Offers
            	if i["ShopStyleSets"] != -1:
            		self.writeDataReference(70, i["ShopStyleSets"]) # For Big Offers
            	else:
            		self.writeDataReference(0, 0) # For Big Offers
            else:
            	self.writeDataReference(0, 0) # For Big Offers
            	self.writeDataReference(0, 0) # For Big Offers
        
        for i in player.DailyOffers:
            self.writeVInt(1)  # RewardCount
            self.writeVInt(i["ItemType"]) # ItemType
            self.writeVInt(i["Amount"])
            if i["BrawlerID"][0] != 0:
                self.writeDataReference(i["BrawlerID"][0], i["BrawlerID"][1]) # CsvID
            else:
                self.writeDataReference(0)
            self.writeVInt(i["Extra"])

            self.writeVInt(i["Currency"])
            self.writeVInt(i["Cost"])
            self.writeVInt(0) # Timer
            self.writeVInt(0) # State
            self.writeVInt(0)
            self.writeBoolean(i["Claim"]) # Claim
            self.writeVInt(player.DailyOffers.index(i) + 1 + len(ShopData["Offers"])) # Offer Index
            self.writeVInt(0)
            self.writeBoolean(i["DailyOffer"])
            self.writeVInt(i["OldPrice"])
            self.writeInt(0)
            self.writeString()
            self.writeBoolean(False)
            self.writeString()
            self.writeVInt(-1)
            self.writeBoolean(False)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeString()
            self.writeBoolean(False)
            self.writeBoolean(False) # Unk
            self.writeDataReference(0, 0) # For Big Offers
            self.writeDataReference(0, 0) # For Big Offers

        self.writeVInt(player.Tokens)
        self.writeVInt(-1)

        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(len(player.SelectedBrawlers))
        for i in player.SelectedBrawlers:
            self.writeDataReference(16, i)

        self.writeString(player.Region)
        self.writeString(player.ContentCreator)

        self.writeVInt(21)
        self.writeLong(2, 1)  # Unknown
        self.writeLong(3, player.TokensGained)  # TokensGained
        player.TokensGained = 0
        self.writeLong(4, player.TrophiesGained)  # TrophiesGained
        player.TrophiesGained = 0
        self.writeLong(6, 0)  # DemoAccount
        self.writeLong(7, player.isDND)  # InvitesBlocked
        try:
        	player.StarPointsGained
        except KeyError:
        	player.StarPointsGained = 0
        self.writeLong(8, player.StarPointsGained)  # StarPointsGained
        player.StarPointsGained = 0
        if player.StarPoints == 0:
        	self.writeLong(9, 0)  # HideStarPoInts
        else:
        	self.writeLong(9, 1)  # ShowStarPoInts
        self.writeLong(10, 0)  # PowerPlayTrophiesGained
        self.writeLong(12, 1)  # Unknown
        self.writeLong(14, player.CoinsGained)  # CoinsGained
        player.CoinsGained = 0
        self.writeLong(15, player.isPlayerAgeSet)  # AgeScreen | 3 = underage (disable social media) | 1 = age popup
        self.writeLong(16, 1)
        self.writeLong(17, 0)  # TeamChatMuted
        self.writeLong(18, 0)  # EsportButton
        self.writeLong(19, 0)  # ChampionShipLivesBuyPopup
        try:
        	player.GemsGained
        except KeyError:
        	player.GemsGained = 0
        self.writeLong(20, player.GemsGained)  # GemsGained
        player.GemsGained = 0
        self.writeLong(21, 0)  # LookingForTeamState
        self.writeLong(22, 1)
        self.writeLong(23, 0)  # Club Trophies Gained
        self.writeLong(24, 1)  # Have already watched club league stupid animation
        self.writeLong(26, 0) # Club Quests Tokens

        self.writeVInt(0) # CooldownEntry

        self.writeVInt(2)  # Brawlpass
        for i in range(Configuration.settings["CurrentBPSeason"] - 1, Configuration.settings["CurrentBPSeason"] + 1):
            self.writeVInt(i)
            if i == Configuration.settings["CurrentBPSeason"] - 1:
            	self.writeVInt(34500)
            elif i == Configuration.settings["CurrentBPSeason"]:
            	self.writeVInt(34500 + player.BPTokens)
            else:
            	self.writeVInt(0)
            try:
            	player.BPActivated
            except KeyError:
            	player.BPActivated = False
            self.writeBoolean(player.BPActivated)
            self.writeVInt(0)

            self.writeByte(2)
            self.writeInt(4294967292)
            self.writeInt(4294967295)
            self.writeInt(511)
            self.writeInt(0)

            self.writeByte(1)
            self.writeInt(4294967292)
            self.writeInt(4294967295)
            self.writeInt(511)
            self.writeInt(0)

        self.writeVInt(0) # ProLeagueSeasonData

        QuestsData = StaticData.QuestsData
        self.writeBoolean(True) # LogicQuests
        self.writeVInt(len(QuestsData)) # Quests Count
        for i in QuestsData:
        	self.writeVInt(QuestsData.index(i)) # Unk
        	self.writeVInt(12) # BPSeason
        	self.writeVInt(i['MissionType']) # Mission Type
        	self.writeVInt(i['AchievedGoal']) # Achieved Goal
        	self.writeVInt(i['QuestGoal']) # Quest Goal
        	self.writeDataReference(16, i['BrawlerID']) #Brawler
        	self.writeVInt(i['GameMode'])# Game Mode
        	self.writeVInt(0) # Process for BattleEnd
        	self.writeVInt(i['RewardType']) # Reward Type
        	self.writeVInt(i['Amount']) # Reward Amount
        	self.writeDataReference(0, 0) # Reward BrawlerID
        	self.writeVInt(i['Extra']) # Reward Extra
        	self.writeVInt(0) # Unk
        	self.writeVInt(i['CurrentLevel']) # Current LVL
        	self.writeVInt(i['MaxLevel']) # Max LVL
        	self.writeVInt(i['Timer']) #Timer
        	self.writeBoolean(i['BP']) # BrawlPass
        	self.writeBoolean(i['Seen']) # Seen
        	self.writeBoolean(False) # Refresh
        	self.writeVInt(0) # Unk
        	self.writeVInt(0) # Unk
        
        self.writeVInt(60) # Quests Refresh Timer
        self.writeVInt(1) # Used QuestsRefresh
        self.writeVInt(3) # Unk
        for x in range(3):
        	self.writeVInt(x) # Unk
        	self.writeVInt(0) # BPSeason
        	self.writeVInt(x) # Mission Type
        	self.writeVInt(0) # Achieved Goal
        	self.writeVInt(500000) # Quest Goal
        	self.writeDataReference(0, 0) #Brawler
        	self.writeVInt(-1)# Game Mode
        	self.writeVInt(0) # Process for BattleEnd
        	
        	self.writeVLong(0, 1)
        	
        	self.writeVInt(9339)
        	self.writeBoolean(True)

        self.writeBoolean(True)
        self.writeVInt(ownedPinsCount + ownedThumbnailCount)  # Vanity Count
        for i in player.OwnedPins:
            self.writeDataReference(52, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)

        for i in player.OwnedThumbnails:
            self.writeDataReference(28, i)
            self.writeVInt(1)
            for i in range(1):
                self.writeVInt(1)
                self.writeVInt(1)

        self.writeBoolean(True) # Power League Array
        # Power League Data Array Start #
        self.writeVInt(8) # Season
        self.writeVInt(17) # Rank Solo League
        self.writeVInt(8) # Season
        self.writeVInt(19) # Rank Team League
        self.writeVInt(0) # Unk
        self.writeVInt(17) # High Rank Solo League
        self.writeVInt(0) # Unk
        self.writeVInt(19) # High Rank Team League
        self.writeVInt(0) # Unk
        self.writeBoolean(True) # Eligibility for an award
        self.writeVInt(0)
        self.writeVInt(0) # League PlayerData
        # Power League Data Array End #

        self.writeInt(0)

        self.writeVInt(0)

        if Configuration.settings["ChallengeEnabled"]:
        	ChallengeStages = Configuration.settings["ChallengeStages"]
        else:
        	ChallengeStages = 0
        
        EventsData = StaticData.EventsData
        Events = []
        for i in EventsData:
        	if i['ID'] != -1:
        		Events.append(EventsData.index(i) + 1)
        
        self.writeVInt(len(Events) + 8 + ChallengeStages) # Count

        for x in range(len(Events)):
        	self.writeVInt(Events[x])
        self.writeVInt(14)
        self.writeVInt(15)
        self.writeVInt(16)
        self.writeVInt(17)
        self.writeVInt(18)
        if Configuration.settings["ChallengeEnabled"]:
        	for i in range(Configuration.settings["ChallengeStages"]):
        		self.writeVInt(20 + i)
        self.writeVInt(30)
        self.writeVInt(31)
        self.writeVInt(32)

        EventsData = StaticData.EventsData
        
        self.writeVInt(len(Events) + 4 + int(Configuration.settings["MysteryModeEnabled"]) + ChallengeStages) # Events Count
        for i in EventsData:
              # Default Slots Start Array #
              if i['ID'] == -1:
              	continue
              self.writeVInt(-1)
              self.writeVInt(EventsData.index(i) + 1)  # EventType
              self.writeVInt(i['CountdownTimer'])  # EventsBeginCountdown
              self.writeVInt(i['Timer'])  # Timer
              self.writeVInt(i['TokensReward'])  # tokens reward for new event
              self.writeDataReference(15, i['ID'])  # MapID
              self.writeVInt(-64)  # GameModeVariation
              self.writeVInt(i['Status'])  # Status
              self.writeString()
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              if i['Modifier'] > 0:
                 self.writeBoolean(True)
                 self.writeVInt(i['Modifier']) #Modifer ID
              else:
                 self.writeBoolean(False)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeBoolean(False)  # Map Maker Map Structure Array
              self.writeVInt(0)
              self.writeBoolean(False)  # Power League Data Array
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeBoolean(False) # ChronosTextEntry
              self.writeBoolean(False)
              self.writeBoolean(False) # ChronosTextEntry
              self.writeBoolean(False)
              self.writeVInt(-1)
              self.writeBoolean(False) # ChronosFileEntry
              self.writeBoolean(False)
              self.writeVInt(-1)
              # Default Slots End Array #

        # Challenge Slot Start Array #
        try:
        	player.Challenges
        except KeyError:
        	player.Challenges = {}
        try:
            challenge = Configuration.settings["ChallengeLogicName"]
            player.Challenges[challenge]
        except KeyError:
        	player.Challenges[challenge] = {'Seen': False, 'Defeates': 0, 'Wins': 0}
        challenge = Configuration.settings["ChallengeLogicName"]
        challengeData = player.Challenges[challenge]
        if Configuration.settings["ChallengeEnabled"]:
        	for i in range(Configuration.settings["ChallengeStages"]):
        		self.writeVInt(-1)
        		self.writeVInt(20 + i)  # EventType
        		self.writeVInt(0)  # EventsBeginCountdown
        		self.writeVInt(51208)  # Timer
        		self.writeVInt(0)  # tokens reward for new event
        		self.writeDataReference(15, Configuration.settings["ChallengeMaps"][i])  # MapID
        		self.writeVInt(-64)  # GameModeVariation
        		if challengeData["Seen"] == False:
        			self.writeVInt(0)  # State
        		elif challengeData["Seen"] == True:
        			self.writeVInt(1)  # State
        		elif challengeData["Wins"] >= 3:
        			self.writeVInt(2)  # State
        		self.writeString() #?
        		self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Type"]) # Challenge FinalReward
        		self.writeVInt(challengeData["Defeates"]) #Defeates
        		self.writeVInt(Configuration.settings["ChallengeMapsWins"][i]) #Wins need
        		self.writeVInt(0)  # Modifiers
        		self.writeVInt(challengeData["Wins"]) #Wins
        		self.writeVInt(Configuration.settings["ChallengeVariation"]) #Challenge Variation
        		self.writeBoolean(False)  # Map Maker Map Structure Array
        		self.writeVInt(0) #Defeates(if buyed lives)
        		self.writeBoolean(False)  # Power League Data Array
        		self.writeVInt(0) #?
        		self.writeVInt(0) #?
        		self.writeBoolean(True) # ChronosTextEntry
        		self.writeInt(0)
        		self.writeString(Configuration.settings["ChallengeName"])
        		self.writeBoolean(False)# Stage Name
        		self.writeBoolean(False) # ChronosTextEntry
        		self.writeBoolean(True) # Challenge Final Reward
        		for x in range(1):
        			self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Type"])
        			self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Amount"])
        			self.writeDataReference(Configuration.settings["ChallengeFinalReward"]["Brawler"][0], Configuration.settings["ChallengeFinalReward"]["Brawler"][1])
        			self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Extra"])
        		self.writeVInt(1) # Challenge Lives Array
        		for x in range(1):
        			self.writeVInt(0) # Gems
        		self.writeBoolean(True) # ChronosFileEntry
        		for x in range(1):
        		          self.writeString("/f4c4740582e48fd0a83e72b3c81db55171ac2ab4/ttts.svg?token=AQQNJ237QLNPSPSOCJMKFIDEB3ZR4")
        		          self.writeString("a381434ab2e7fe7f2100c00d3d05ee41743ae55c")
        		self.writeBoolean(False) # Array
        		self.writeVInt(-1) # Array
        # Challenge Slot Array End #
        
        # Club League Slots Start Array #
        # Club League Default Map Array #
        self.writeVInt(-1)
        self.writeVInt(16)  # EventType
        self.writeVInt(432000)  # EventsBeginCountdown
        self.writeVInt(51208)  # Timer
        self.writeVInt(0)  # tokens reward for new event
        self.writeDataReference(15, 7)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(False)  # Power League Data Array
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        
        # Club League Power Match Array #
        self.writeVInt(-1)
        self.writeVInt(17)  # EventType
        self.writeVInt(432000)  # EventsBeginCountdown
        self.writeVInt(51208)  # Timer
        self.writeVInt(0)  # tokens reward for new event
        self.writeDataReference(15, 25)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString() 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeVInt(0)  # Modifiers
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(False)  # Power League Data Array
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        # Club League Slots End Array #
        
        # Power League Solo Mode #
        self.writeVInt(-1)
        self.writeVInt(14)  # EventType
        self.writeVInt(0)  # EventsBeginCountdown
        self.writeVInt(99999)  # Timer
        self.writeVInt(0)  # tokens reward for new event
        self.writeDataReference(0, 0)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(True)  # Power League Data Array
        # Power League Data Array Start #
        self.writeVInt(9) # Season
        self.writeString("TID_BRAWL_PASS_SEASON_12") # Name Season
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3) # Quests Count
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(30) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(106) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(2) # Quest Type
        self.writeVInt(7) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(107) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(60) # Wins need
        self.writeVInt(1) # Item Array
        self.writeVInt(26) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(534) # SkinID
        
        self.writeVInt(19) # Road Count
        
        self.writeVInt(1) # Rank
        self.writeVInt(500) # Starpoints
        self.writeVInt(2) # Rank
        self.writeVInt(1000) # Starpoints
        self.writeVInt(3)  # Rank
        self.writeVInt(2000) # Starpoints
        self.writeVInt(4)  # Rank
        self.writeVInt(2500) # Starpoints
        self.writeVInt(5)  # Rank
        self.writeVInt(3000) # Starpoints
        self.writeVInt(6)  # Rank
        self.writeVInt(3750) # Starpoints
        self.writeVInt(7)  # Rank
        self.writeVInt(4500) # Starpoints
        self.writeVInt(8)  # Rank
        self.writeVInt(5500) # Starpoints
        self.writeVInt(9)  # Rank
        self.writeVInt(7000) # Starpoints
        self.writeVInt(10)  # Rank
        self.writeVInt(8750) # Starpoints
        self.writeVInt(11)  # Rank
        self.writeVInt(10000) # Starpoints
        self.writeVInt(12)  # Rank
        self.writeVInt(12500) # Starpoints
        self.writeVInt(13)  # Rank
        self.writeVInt(15000) # Starpoints
        self.writeVInt(14)  # Rank
        self.writeVInt(17500) # Starpoints
        self.writeVInt(15)  # Rank
        self.writeVInt(20000) # Starpoints
        self.writeVInt(16)  # Rank
        self.writeVInt(25000) # Starpoints
        self.writeVInt(17)  # Rank
        self.writeVInt(30000) # Starpoints
        self.writeVInt(18)  # Rank
        self.writeVInt(40000) # Starpoints
        self.writeVInt(19)  # Rank
        self.writeVInt(50000) # Starpoints
        # Power League Data Array End #
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        
        # Power League Team Mode #
        self.writeVInt(-1)
        self.writeVInt(15)  # EventType
        self.writeVInt(0)  # EventsBeginCountdown
        self.writeVInt(99999)  # Timer
        self.writeVInt(0)  # tokens reward for new event
        self.writeDataReference(0, 0)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3)
        self.writeVInt(0)  # Modifiers
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(True)  # Power League Data Array
        # Power League Data Array Start #
        self.writeVInt(9) # Season
        self.writeString("TID_BRAWL_PASS_SEASON_12") # Name Season
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3) # Quests Count
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(30) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(106) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(2) # Quest Type
        self.writeVInt(7) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(107) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(60) # Wins need
        self.writeVInt(1) # Item Array
        self.writeVInt(26) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(534) # SkinID
        
        self.writeVInt(19) # Road Count
        
        self.writeVInt(1) # Rank
        self.writeVInt(500) # Starpoints
        self.writeVInt(2) # Rank
        self.writeVInt(1000) # Starpoints
        self.writeVInt(3)  # Rank
        self.writeVInt(2000) # Starpoints
        self.writeVInt(4)  # Rank
        self.writeVInt(2500) # Starpoints
        self.writeVInt(5)  # Rank
        self.writeVInt(3000) # Starpoints
        self.writeVInt(6)  # Rank
        self.writeVInt(3750) # Starpoints
        self.writeVInt(7)  # Rank
        self.writeVInt(4500) # Starpoints
        self.writeVInt(8)  # Rank
        self.writeVInt(5500) # Starpoints
        self.writeVInt(9)  # Rank
        self.writeVInt(7000) # Starpoints
        self.writeVInt(10)  # Rank
        self.writeVInt(8750) # Starpoints
        self.writeVInt(11)  # Rank
        self.writeVInt(10000) # Starpoints
        self.writeVInt(12)  # Rank
        self.writeVInt(12500) # Starpoints
        self.writeVInt(13)  # Rank
        self.writeVInt(15000) # Starpoints
        self.writeVInt(14)  # Rank
        self.writeVInt(17500) # Starpoints
        self.writeVInt(15)  # Rank
        self.writeVInt(20000) # Starpoints
        self.writeVInt(16)  # Rank
        self.writeVInt(25000) # Starpoints
        self.writeVInt(17)  # Rank
        self.writeVInt(30000) # Starpoints
        self.writeVInt(18)  # Rank
        self.writeVInt(40000) # Starpoints
        self.writeVInt(19)  # Rank
        self.writeVInt(50000) # Starpoints
        # Power League Data Array End #
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        
        # Mystery Mode #
        if Configuration.settings["MysteryModeEnabled"]:
        	self.writeVInt(-1)
        	self.writeVInt(18)  # EventType
        	self.writeVInt(0)  # EventsBeginCountdown
        	self.writeVInt(51208)  # Timer
        	self.writeVInt(0)  # tokens reward for new event
        	self.writeDataReference(15, random.choice(Configuration.settings["MysteryModeMaps"]))  # MapID
        	self.writeVInt(-64)  # GameModeVariation
        	self.writeVInt(2)  # State
        	self.writeString()
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(0)
        	Modifiers = [1, 2, 3, 4, 5, 11, 13, 14, 16]
        	modifierscount = random.randint(1, 4)
        	modifier1 = random.choice(Modifiers)
        	modifier2 = random.choice(Modifiers)
        	while modifier2 == modifier1:
        		modifier2 = random.choice(Modifiers)
        	modifier3 = random.choice(Modifiers)
        	while modifier3 == modifier2 or modifier3 == modifier1:
        		modifier3 = random.choice(Modifiers)
        	modifier4 = random.choice(Modifiers)
        	while modifier4 == modifier3 or modifier4 == modifier2 or modifier4 == modifier1:
        		modifier4 = random.choice(Modifiers)
        	if Configuration.settings["MysteryModeModifiersEnabled"]:
        		self.writeVInt(modifierscount)  # Modifiers
        		if modifierscount >= 1:
        			self.writeVInt(modifier1)
        		if modifierscount >= 2:
        			self.writeVInt(modifier2)
        		if modifierscount >= 3:
        			self.writeVInt(modifier3)
        		if modifierscount == 4:
        			self.writeVInt(modifier4)
        	else:
        		self.writeVInt(0)  # Modifiers
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeBoolean(False)  # Map Maker Map Structure Array
        	self.writeVInt(0)
        	self.writeBoolean(False)  # Power League Data Array
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeBoolean(True)  # ChronosTextEntry
        	self.writeInt(0)
        	self.writeString("Mystery Mode")
        	self.writeBoolean(False)
        	self.writeBoolean(True) # ChronosTextEntry
        	self.writeInt(0)
        	self.writeString(Configuration.settings["MysteryModeName"])
        	self.writeBoolean(False)
        	self.writeVInt(-1)
        	self.writeBoolean(False) # ChronosFileEntry
        	self.writeBoolean(False)
        	self.writeVInt(-1)

        self.writeVInt(0) # Comming Events

        ByteStreamHelper.encodeIntList(self, [20, 35, 75, 140, 290, 480, 800, 1250, 1875, 2800]) # Brawler Upgrade Cost
        ByteStreamHelper.encodeIntList(self, [20, 50, 140, 280]) # Shop Coins Price
        ByteStreamHelper.encodeIntList(self, [150, 400, 1200, 2600]) # Shop Coins Amount

        self.writeBoolean(True)  # Show Offers Packs

        self.writeVInt(0) # ReleaseEntry

        self.writeVInt(24)  # IntValueEntry

        self.writeLong(10008, 501)
        self.writeLong(65, 2)
        self.writeLong(1, 41000000 + 45)  # ThemeID
        self.writeLong(60, 36270)
        self.writeLong(66, 0) # Garveyard Shift
        self.writeLong(61, 36270)  # SupportDisabled State | if 36218 < state its true
        self.writeLong(47, 41381)
        self.writeLong(29, Configuration.settings["SkinPack"])  # Skin Group Active For Campaign
        self.writeLong(48, 26217)
        self.writeLong(50, 0)  # Coming up quests placeholder
        self.writeLong(1100, 500)
        self.writeLong(1101, 500)
        self.writeLong(1003, 1)
        self.writeLong(36, 0)
        self.writeLong(14, Configuration.settings["DoubleTokenEvent"])  # Double Token Event
        self.writeLong(31, Configuration.settings["GoldRushEvent"])  # Gold rush event
        self.writeLong(79, 149999)
        self.writeLong(80, 160000)
        self.writeLong(28, Configuration.settings["ChallengeLives"]) # Challenge Lives
        self.writeLong(74, 1)
        self.writeLong(78, 1)
        self.writeLong(17, 4)
        self.writeLong(10046, 1)
        self.writeLong(87, 1)

        self.writeVInt(3)  # Timed Int Value Entry

        self.writeVInt(14)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(739760) # Time left

        self.writeVInt(29)
        self.writeVInt(15)
        self.writeVInt(0)
        self.writeVInt(691200) # Time left

        self.writeVInt(29)
        self.writeVInt(10)
        self.writeVInt(0)
        self.writeVInt(1330340) # Time left

        self.writeVInt(0)  # Custom Event

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeLong(player.ID[0], player.ID[1])  # PlayerID

        try:
        	player.Notifications
        except KeyError:
        	player.Notifications = []
        notifications = player.Notifications
        notifications.sort(key = lambda x: x["Number"], reverse = True)
        self.writeVInt(len(notifications)) # Notification Count
        for x in notifications:
        	# BaseNotification::encode
        	self.writeVInt(x["Type"])
        	self.writeInt(notifications.index(x)) # Notification Index
        	self.writeBoolean(x["Readed"]) # Read
        	self.writeInt(x["Timer"]) # Time Ago
        	self.writeString(x["Text"])
        	self.writeVInt(0)
        	if x["Type"] == 81:
        		self.writeVInt(1)
        	if x["Type"] == 72 or x["Type"] == 94:
        		# VanityItemRewardNotification or SkinRewardNotification
        		DataRef = str(x["DataRef"][0]) + "000000"
        		Item = int(DataRef) + x["DataRef"][1]
        		self.writeVInt(Item)
        	if x["Type"] == 63 or x["Type"] == 70:
        		# ChallengeRewardNotification
        		self.writeVInt(1)
        		for i in range(1):
        			self.writeVInt(x["Reward"]["Type"])
        			self.writeVInt(x["Reward"]["Amount"])
        			self.writeDataReference(x["Reward"]["Brawler"][0], x["Reward"]["Brawler"][1])
        			self.writeVInt(x["Reward"]["Extra"])
        		self.writeVInt(x["ChallengeVariation"])
        		self.writeVInt(x["Win"])
        		self.writeString(x["ChallengeName"])
        	if x["Type"] == 64:
        		# BoxRewardNotification::encode
        		self.writeVInt(1)
        		self.writeVInt(x["RewardType"])
        		self.writeVInt(x["Amount"])
        	if x["Type"] == 71:
        		# BrawlPassPointRewardNotification::encode
        		self.writeVInt(x["BPSeason"])
        		self.writeVInt(x["Tokens"])
        	
        #self.writeVInt(83)
#        self.writeInt(len(notifications) + 1)
#        self.writeBoolean(False)
#        self.writeInt(0)
#        self.writeString()
#        self.writeVInt(0)
#        self.writeInt(0)
#        self.writeString("Welcome to Fighting Brawl!")
#        self.writeInt(0)
#        self.writeString("Thanks for playing Fighting Brawl!")
#        self.writeInt(0)
#        self.writeString("Go to tg channel")
#        # Banner Data
#        self.writeString("/main/banner44.jpg?token=GHSAT0AAAAAAB5ZJLXFQJZTMRPS7GYCJIW6ZAJACPQ")
#        self.writeString("4d18e345244cab1da4dffd5bbde28720c7acd883")
#        # End
#        self.writeString("brawlstars://extlink?page=https%3A%2F%2Ft.me%2Ffightingbrawl")
#        self.writeVInt(3473)

        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(2) # Days
        self.writeVInt(0) # Day
        self.writeVInt(1) # RewardsCount
        self.writeVInt(4)
        self.writeVInt(1)
        self.writeDataReference(16, 0)
        self.writeVInt(29)
        self.writeBoolean(False)
        
        self.writeVInt(1) # Day
        self.writeVInt(2) # CountRewards
        self.writeVInt(3)
        self.writeVInt(1)
        self.writeDataReference(16, 18)
        self.writeVInt(0)
        self.writeBoolean(False)
        
        self.writeVInt(3)
        self.writeVInt(1)
        self.writeDataReference(16, 19)
        self.writeVInt(0)
        self.writeBoolean(False)
        
        self.writeVInt(2) # Calendars Count
        
        self.writeVInt(1)
        self.writeVInt(3) # Days
        
        self.writeVInt(2) # Day
        self.writeVInt(1) # CountRewards
        self.writeVInt(4)
        self.writeVInt(1)
        self.writeDataReference(16, 18)
        self.writeVInt(158)
        self.writeBoolean(False)
        
        self.writeVInt(3) # Day
        self.writeVInt(1) # CountRewards
        self.writeVInt(34)
        self.writeVInt(5)
        self.writeDataReference(16, 18)
        self.writeVInt(0)
        self.writeBoolean(False)
        
        self.writeVInt(14) # Day
        self.writeVInt(2) # CountRewards
        self.writeVInt(3)
        self.writeVInt(1)
        self.writeDataReference(16, 50)
        self.writeVInt(0)
        self.writeBoolean(False)
        
        self.writeVInt(3)
        self.writeVInt(1)
        self.writeDataReference(16, 43)
        self.writeVInt(0)
        self.writeBoolean(False)
        
        
        self.writeVInt(2)
        self.writeVInt(3) # Days
        
        self.writeVInt(2) # Day
        self.writeVInt(1) # CountRewards
        self.writeVInt(4)
        self.writeVInt(1)
        self.writeDataReference(16, 19)
        self.writeVInt(88)
        self.writeBoolean(False)
        
        self.writeVInt(3) # Day
        self.writeVInt(1) # CountRewards
        self.writeVInt(34)
        self.writeVInt(1)
        self.writeDataReference(16, 19)
        self.writeVInt(0)
        self.writeBoolean(False)
        
        self.writeVInt(14) # Day
        self.writeVInt(2) # CountRewards
        self.writeVInt(3)
        self.writeVInt(1)
        self.writeDataReference(16, 50)
        self.writeVInt(0)
        self.writeBoolean(False)
        
        self.writeVInt(3)
        self.writeVInt(1)
        self.writeDataReference(16, 43)
        self.writeVInt(0)
        self.writeBoolean(False)
        
        
        self.writeVInt(1) # Day
        self.writeVInt(0) # CountdownTimer
        self.writeVInt(120) # Timer
        self.writeVInt(1) # Collected Day
        self.writeVInt(2) # 0 - Darryl, 1 - Penny, 2 -Choice, 3 - Choice(if 15 day exist)

        self.writeVLong(player.ID[0], player.ID[1])
        self.writeVLong(0, 0)
        self.writeVLong(0, 0)

        self.writeString(player.Name)
        self.writeBoolean(player.Registered)

        self.writeInt(0)

        self.writeVInt(16)

        self.writeVInt(4 + ownedBrawlersCount)

        for brawlerInfo in player.OwnedBrawlers.values():
            self.writeDataReference(23, brawlerInfo["CardID"])
            self.writeVInt(-1)
            self.writeVInt(1)

        self.writeDataReference(5, 8)
        self.writeVInt(-1)
        self.writeVInt(player.Coins)

        self.writeDataReference(5, 10)
        self.writeVInt(-1)
        self.writeVInt(player.StarPoints)

        self.writeDataReference(5, 13)
        self.writeVInt(-1)
        self.writeVInt(99999) # Club coins
        
        self.writeDataReference(5, 9)
        self.writeVInt(-1)
        self.writeVInt(1) # Hints Off

        self.writeVInt(ownedBrawlersCount)

        for brawlerID,brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["Trophies"])

        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["HighestTrophies"])

        self.writeVInt(0)

        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["PowerPoints"])

        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["PowerLevel"] - 1)

        self.writeVInt(0)

        self.writeVInt(ownedBrawlersCount)

        for brawlerID, brawlerInfo in player.OwnedBrawlers.items():
            self.writeDataReference(16, brawlerID)
            self.writeVInt(-1)
            self.writeVInt(brawlerInfo["State"])

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(player.Gems)  # Diamonds
        self.writeVInt(player.Gems)  # Free Diamonds
        self.writeVInt(player.Level)  # Player Level
        self.writeVInt(100)
        self.writeVInt(0)  # CumulativePurchasedDiamonds or Avatar User Level Tier | 10000 < Level Tier = 3 | 1000 < Level Tier = 2 | 0 < Level Tier = 1
        self.writeVInt(0)  # Battle Count
        self.writeVInt(0)  # WinCount
        self.writeVInt(0)  # LoseCount
        self.writeVInt(0)  # WinLooseStreak
        self.writeVInt(0)  # NpcWinCount
        self.writeVInt(0)  # NpcLoseCount
        self.writeVInt(2)  # TutorialState | shouldGoToFirstTutorialBattle = State == 0
        self.writeVInt(5)
        self.writeVInt(0)
        self.writeVInt(0)

    def decode(self):
        fields = {}
        # fields["AccountID"] = self.readLong()
        # fields["HomeID"] = self.readLong()
        # fields["PassToken"] = self.readString()
        # fields["FacebookID"] = self.readString()
        # fields["GamecenterID"] = self.readString()
        # fields["ServerMajorVersion"] = self.readInt()
        # fields["ContentVersion"] = self.readInt()
        # fields["ServerBuild"] = self.readInt()
        # fields["ServerEnvironment"] = self.readString()
        # fields["SessionCount"] = self.readInt()
        # fields["PlayTimeSeconds"] = self.readInt()
        # fields["DaysSinceStartedPlaying"] = self.readInt()
        # fields["FacebookAppID"] = self.readString()
        # fields["ServerTime"] = self.readString()
        # fields["AccountCreatedDate"] = self.readString()
        # fields["StartupCooldownSeconds"] = self.readInt()
        # fields["GoogleServiceID"] = self.readString()
        # fields["LoginCountry"] = self.readString()
        # fields["KunlunID"] = self.readString()
        # fields["Tier"] = self.readInt()
        # fields["TencentID"] = self.readString()
        #
        # ContentUrlCount = self.readInt()
        # fields["GameAssetsUrls"] = []
        # for i in range(ContentUrlCount):
        #     fields["GameAssetsUrls"].append(self.readString())
        #
        # EventUrlCount = self.readInt()
        # fields["EventAssetsUrls"] = []
        # for i in range(EventUrlCount):
        #     fields["EventAssetsUrls"].append(self.readString())
        #
        # fields["SecondsUntilAccountDeletion"] = self.readVInt()
        # fields["SupercellIDToken"] = self.readCompressedString()
        # fields["IsSupercellIDLogoutAllDevicesAllowed"] = self.readBoolean()
        # fields["isSupercellIDEligible"] = self.readBoolean()
        # fields["LineID"] = self.readString()
        # fields["SessionID"] = self.readString()
        # fields["KakaoID"] = self.readString()
        # fields["UpdateURL"] = self.readString()
        # fields["YoozooPayNotifyUrl"] = self.readString()
        # fields["UnbotifyEnabled"] = self.readBoolean()
        # super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24101

    def getMessageVersion(self):
        return self.messageVersion