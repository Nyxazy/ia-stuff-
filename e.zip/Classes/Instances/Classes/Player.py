import json
import random
import string
from Classes.Files.Classes.Cards import Cards


class Player:
    ClientVersion = "0.0.0"

    ID = [0, 1]
    AllianceID = [0, 0]
    TeamID = [0, 0]
    Token = ""
    Name = "Brawler"
    Registered = False
    Thumbnail = 0
    Namecolor = 0
    Region = "US"
    ContentCreator = ""

    Coins = 100
    CoinsGained = 0
    Gems = 0
    GemsGained = 0
    StarPoints = 0
    StarPointsGained = 0
    ClubCoins = 0
    Trophies = 0
    HighestTrophies = 0
    TrophiesGained = 0
    TrophyRoadTier = 99999
    Experience = 0
    Level = 1
    Tokens = 200
    TokensGained = 0
    TokensDoubler = 0
    tpw = 0
    isPlayerAgeSet = 1
    RegionRefID = 0
    isDND = 0
    MapRef = 0
    
    PushasedOffers = []
    
    delivery_items = {}
    
    Logs = []
    
    banned = False
    
    BPTokens = 5000
    
    Notifications = []
    
    BPActivated = False
    
    Challenges = {}
    
    DailyOffers = []

    BrawlersSelectedSkins = {}
    SelectedBrawlers = [0, 1, 8]
    RandomizerSelectedSkins = []
    OwnedPins = []
    OwnedThumbnails = []
    OwnedBrawlers = {
        0: {'CardID': 0, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        1: {'CardID': 4, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
        8: {'CardID': 32, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
    }

    def __init__(self):
        pass

    def getDataTemplate(self, highid, lowid, token):
        if highid == 0 or lowid == 0:
            self.ID[0] = int(''.join([str(random.randint(1, 9)) for _ in range(1)]))
            self.ID[1] = int(''.join([str(random.randint(1, 9)) for _ in range(8)]))
            self.Token = ''.join(random.choice(string.ascii_letters + string.digits) for i in range(40))
        else:
            self.ID[0] = highid
            self.ID[1] = lowid
            self.Token = token

        DBData = {
            'ID': self.ID,
            'Token': self.Token,
            'Name': self.Name,
            'AllianceID': self.AllianceID,
            'TeamID': self.TeamID,
            'Registered': self.Registered,
            'Thumbnail': self.Thumbnail,
            'Namecolor': self.Namecolor,
            'Region': self.Region,
            'ContentCreator': self.ContentCreator,
            'Coins': self.Coins,
            'CoinsGained': self.CoinsGained,
            'Gems': self.Gems,
            'GemsGained': self.GemsGained,
            'StarPoints': self.StarPoints,
            'StarPointsGained': self.StarPointsGained,
            'ClubCoins': self.ClubCoins,
            'Trophies': self.Trophies,
            'HighestTrophies': self.HighestTrophies,
            'TrophiesGained': self.TrophiesGained,
            'TrophyRoadTier': self.TrophyRoadTier,
            'Experience': self.Experience,
            'Level': self.Level,
            'Tokens': self.Tokens,
            'TokensGained': self.TokensGained,
            'TokensDoubler': self.TokensDoubler,
            'PushasedOffers': self.PushasedOffers,
            'delivery_items': self.delivery_items,
            'Logs': self.Logs,
            'banned': self.banned,
            'BPTokens': self.BPTokens,
            'Notifications': self.Notifications,
            'BPActivated': self.BPActivated,
            'Challenges': self.Challenges,
            'DailyOffers': self.DailyOffers,
            'BrawlersSelectedSkins': self.BrawlersSelectedSkins,
            'SelectedBrawlers': self.SelectedBrawlers,
            'OwnedPins': self.OwnedPins,
            'OwnedThumbnails': self.OwnedThumbnails,
            'OwnedBrawlers': self.OwnedBrawlers,
            'tpw': self.tpw,
            'isPlayerAgeSet': self.isPlayerAgeSet,
            'isDND': self.isDND
        }
        return DBData

    def toJSON(self):
        return json.loads(json.dumps(self, default=lambda o: o.__dict__,
            sort_keys=True, indent=4))
