import socket

import Configuration
from Classes.Connection import Connection
from colorama import Fore, Back, Style


class ServerConnection:
    def __init__(self, address):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if Configuration.settings["DisableNagle"] == True:
            self.server.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, True)
        self.setupConnection(address)

    def setupConnection(self, address):
        self.server.bind(address)
        print(Fore.GREEN + "PFPS Started on 0.0.0.0:9347")
        while True:
            self.server.listen()
            socket, address = self.server.accept()
            print(Fore.BLUE + "Got New Connection")
            Connection(socket, address).start()
