import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Files.Classes.Skins import Skins


class LogicSelectSkinCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["SkinID"] = calling_instance.readDataReference()
        fields["Unk"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        ownedSkins = []
        for brawlerInfo in player_data["OwnedBrawlers"].values():
            try:
                ownedSkins.extend(brawlerInfo["Skins"])
            except KeyError:
                continue
        check = False
        if fields["SkinID"] in ownedSkins:
        	check = True
        brawlerID = Skins.getBrawlerBySkin(self, fields["SkinID"][1])
        try:
        	player_data["BrawlersSelectedSkins"]
        except KeyError:
        	player_data["BrawlersSelectedSkins"] = {}
        player_data["BrawlersSelectedSkins"][str(brawlerID)] = fields["SkinID"][1]
        if check == False:
        	db_instance.updatePlayerData(player_data, calling_instance)

    def getCommandType(self):
        return 506