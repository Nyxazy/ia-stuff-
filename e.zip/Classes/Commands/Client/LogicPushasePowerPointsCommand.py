import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler


pp = []
usedpp = []


class LogicPushasePowerPointsCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["BrawlerID"] = calling_instance.readDataReference()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        global pp
        global usedpp
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        boxes = player_data['delivery_items']['Boxes']
        for i in boxes:
        	rewards = i['Items']
        	for x in rewards:
        		if x['RewardID'] == 19:
        			if x['Amount'] not in usedpp:
        				pp.append(x['Amount'])
        brawler = fields["BrawlerID"][1]
        for i,v in player_data["OwnedBrawlers"].items():
            	if i == str(brawler):
            		v["PowerPoints"] += pp[0]
            		usedpp.append(pp[0])
        if len(pp) == 1:
        	usedpp.clear
        player_data["delivery_items"] = {
        'Boxes': []
        }
        box = {
        'Type': 0,
        'Items': []
        }
        box['Type'] = 100
        item = {'Amount': pp[0], 'DataRef': [16, brawler], 'RewardID': 6}
        box['Items'].append(item)
        player_data["delivery_items"]['Boxes'].append(box)
        db_instance.updatePlayerData(player_data, calling_instance)
        pp.pop(0)
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 203}
        fields["PlayerID"] = calling_instance.player.ID
        Messaging.sendMessage(24111, fields)

    def getCommandType(self):
        return 551