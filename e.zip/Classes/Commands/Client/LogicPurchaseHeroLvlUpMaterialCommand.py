import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler


class LogicPurchaseHeroLvlUpMaterialCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        LogicCommand.encode(self, fields)
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["HeroLvlUpMaterialID"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        if fields["HeroLvlUpMaterialID"] == 0:
          player_data["Coins"] += 150
          player_data["Gems"] -= 20
        if fields["HeroLvlUpMaterialID"] == 1:
          player_data["Coins"] += 400
          player_data["Gems"] -= 50
        if fields["HeroLvlUpMaterialID"] == 2:
          player_data["Coins"] += 1200
          player_data["Gems"] -= 140
        if fields["HeroLvlUpMaterialID"] == 3:
          player_data["Coins"] += 2600
          player_data["Gems"] -= 280
        db_instance.updatePlayerData(player_data, calling_instance)

    def getCommandType(self):
        return 521