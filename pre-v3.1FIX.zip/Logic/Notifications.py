from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import sqlite3

import datetime

class Notifications:
    """
    << Notification IDs List >>
    
    81 = Custom Message
    82 = Club Message
    74 = Ticket Compensation Message
    77 = ???
    79 = Season End
    
    """
    def __init__(self):
        self.message()

    def message(self):
        #self.player.vip = vip
        #self.player.low_id = low_id
        #self.player.token = token
        global vip
        if self.player.vip == 2:
            vip = "<c43ff00>[<c87ff00>V<ccbff00>I<cccff00>P<cddff00>]</c>"
        elif self.player.vip == 1:
            vip = "<cffff00>[LITE]</c>"
        elif self.player.vip == 3:
            vip = "<c00f2ff>[<c00e5ff>P<c00d8ff>R<c00cbff>E<c00bfff>M<c00bfff>I<c0098ff>U<c0072ff>M<c004cff>]</c>"
        else:
            vip = "Нету"

        messages = [

            {
                'NotificationID': 81,
                'NotificationIndex': 3,
                'NotificationRead': False,
                'NotificationTime': 0,
                'NotificationText': f'    Добро пожаловать в <c82cbff>E<c61bfff>c<c41b4ff>h<c20a8ff>o<c099dff> <c00a6ff>B<c00afff>r<c00b9ff>a<c00c2ff>w<c00ccff>l</c>!\n\
                    TGC - <c8bceff>t<c74c6ff>.<c5dbeff>m<c45b5fe>e<c2eadff>/<c17a5ff>e<c039dff>c<c00a3ff>h<c00aaff>o<c00b1ff>b<c00b7fe>r<c00beff>a<c00c5ff>w<c00cbff>l</c>\n\
                    Привилегия: {vip}\n\
                    eID: <c00eeff>{self.player.low_id}</c>',
                'NotificationType': 0
            }
            
        ]
        
        if self.player.Notifications == "yes":
            ms = {
                'NotificationID': 89,
                'NotificationIndex': 228228,
                'NotificationRead': False,
                'NotificationTime': 0,
                'NotificationText': "Спасибо за покупку!",
                'NotificationType': 0,
                'Gems': self.player.notifgems}
            messages.append(ms)


        if self.player.tickets >= 100:
            date = datetime.datetime.today().weekday()
            if date == 6:
                t = int(self.player.tickets / 2)
                ms = {
                    'NotificationID': 89,
                    'NotificationIndex': 2281337,
                    'NotificationRead': False,
                    'NotificationTime': 0,
                    'NotificationText': "Обмен купонов на кристаллы",
                    'NotificationType': 0,
                    'Gems': t}
                messages.append(ms)


        


        if 59 not in self.player.UnlockedSkins['Skins']:
            db = sqlite3.connect('Database/BotUser/users.db')
            cursor = db.cursor()
            cursor.execute(f'SELECT * FROM accountconnect WHERE lowID = {self.player.low_id}')
            info = cursor.fetchall()
            cursor.close()
            if not info:
                pass
            else:
                ms = {
                    'NotificationID': 90,
                    'NotificationIndex': 228227,
                    'NotificationRead': False,
                    'NotificationTime': 0,
                    'NotificationText': "Награда за привязку аккаунта к Echo ID",
                    'NotificationType': 1,
                    'SkinID': 59}
                messages.append(ms)


        if 52 not in self.player.UnlockedSkins['Skins']:

            if 1 > 2:
                pass
            else:
                ms = {
                    'NotificationID': 90,
                    'NotificationIndex': 228229,
                    'NotificationRead': False,
                    'NotificationTime': 0,
                    'NotificationText': "Бесплатно!",
                    'NotificationType': 1,
                    'SkinID': 52}
                messages.append(ms)
            
            
            
            
            


        return messages 
    
    def EncodeNotificationsMessages(self):
        count = len(Notifications.message(self))
        self.writeVint(count) # Count
        for i in range(count):
            item = Notifications.message(self)[i]
            
            self.writeVint(item['NotificationID'])
            self.writeInt(item['NotificationIndex'])
            self.writeBoolean(item['NotificationRead'])
            self.writeInt(item['NotificationTime'])
            self.writeString(item['NotificationText'])
            
            if item['NotificationID'] == 81:
                self.writeVint(item['NotificationType']) # 0 - Support Service, 1 - System

            elif item['NotificationID'] == 82:
                self.writeString(item['SenderName'])
                self.writeVint(100)
                self.writeVint(28000000 + item['SenderThumbnail'])
                self.writeVint(43000000 + item['SenderNameColor'])
                #self.writeVint(-1)
            
            elif item['NotificationID'] == 74:
                self.writeVint(item['Tickets'])
                self.writeVint(item['Gems'])
            
            elif item['NotificationID'] == 77:
                self.writeVint(0)
                for i in range(1):
                    self.writeVint(1)
                    self.writeVint(14)  # ItemType
                    self.writeVint(1)
                    self.writeVint(0)  # CsvID
                    self.writeVint(0)
                self.writeVint(7)
                self.writeVint(3)
                self.writeString('SUMMER SPORTS CHALLENGE!')

            elif item['NotificationID'] == 79:
                self.writeVint(len(item['Brawlers'])) # Brawlers Count
                for brawler in range(len(item['Brawlers'])):
                    self.writeVint(16000000 + brawler) # Brawler ID
                    self.writeVint(item['TrophiesPlus'][brawler]) # Brawler Trophies
                    self.writeVint(item['TrophiesMinus'][brawler]) # Brawler Trophy Loss
                    self.writeVint(item['Starpoints'][brawler]) # Star Points Gained
            elif item['NotificationID'] == 89: # Кристаллы
                self.writeVint(0)
                self.writeVint(item['Gems'])
 
            elif item['NotificationID'] == 90: # Бравлер/скин (несколько штук)
                self.writeVint(0)
                if item['NotificationType'] == 0: # Brawler
                    self.writeVint(16000000 + item['BrawlerID'])
                else: # Skin
                    self.writeVint(29000000 + item['SkinID'])
                self.writeVint(1)
            elif item['NotificationID'] == 91: # Билеты
                self.writeVint(0)
                self.writeVint(item['Tickets'])
 
