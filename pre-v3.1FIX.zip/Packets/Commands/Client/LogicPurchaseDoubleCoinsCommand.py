from Database.DatabaseManager import DataBase
from Logic.Shop import Shop
from Utils.Reader import BSMessageReader

class LogicPurchaseDoubleCoinsCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self):
        cost = Shop.token_doubler['Cost']
        value = Shop.token_doubler['Amount']

        newGems = self.player.gems - cost
        DataBase.replaceValue(self, 'gems', newGems)

        newTokens = self.player.tokensdoubler + value
        DataBase.replaceValue(self, 'tokensdoubler', newTokens)