from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand
from Packets.Commands.Server.LogicBrawlerDataCommand import LogicBrawlerDataCommand
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Database.DatabaseManager import DataBase
from Logic.Shop import Shop
from Packets.Commands.Server.ShopResponse import ShopResponse

from Utils.Reader import BSMessageReader

class LogicPurchaseOfferCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.offer_index = self.read_Vint()
        self.brawlerID = self.read_Vint()

    def process(self):
        Shop.loadOffers(self)
        offers = self.offers
        id = offers[self.offer_index]['ID']
        type = offers[self.offer_index]['ShopType']
        cost = offers[self.offer_index]['Cost']
        brawlerID = offers[self.offer_index]['BrawlerID']
        count = offers[self.offer_index]['Multiplier']
        skinID = offers[self.offer_index]['SkinID']

        def res(type):
            if type == 0 or type == 2:
                newGems = self.player.gems - cost
                self.player.gems = newGems
                DataBase.replaceValue(self, 'gems', newGems)
                DataBase.loadAccount(self)
            elif type == 1:
                self.player.gold -= cost
                DataBase.replaceValue(self, 'gold', self.player.gold)
                DataBase.loadAccount(self)
            elif type == 3:
                newStarPoints = self.player.star_points - cost
                self.player.star_points = newStarPoints
                DataBase.replaceValue(self, 'starpoints', newStarPoints)
                DataBase.loadAccount(self)
        ii = -1
        for i in id:
            ii += 1

            if i in [6, 10, 14]:

                if i in [6]:
                    self.player.box_id = 5

                elif i == 14:
                    self.player.box_id = 4

                elif i == 10:
                    self.player.box_id = 3

                res(type)

                if self.player.low_id in offers[self.offer_index]['WhoBuyed']:
                    pass
                else:
                

                    LogicBoxDataCommand(self.client, self.player, 0, count[ii]).send()


                    Shop.UpdateOfferData(self, self.offer_index)
            
            elif i == 16:
                Shop.UpdateOfferData(self, self.offer_index)
                ShopResponse(self.client, self.player, 0, {"id": 8}, count[ii]).send()
                self.player.gems += count[ii]
                DataBase.replaceValue(self, 'gems', self.player.gems)
            elif i == 0:
                Shop.UpdateOfferData(self, self.offer_index)
            elif i == 12:
                Shop.UpdateOfferData(self, self.offer_index)
                ShopResponse(self.client, self.player, 0, {"id": 6, "scid": self.brawlerID}, count[ii]).send()
                self.player.brawlers_upgradium[str(self.brawlerID)] += count[ii]
                DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)

            elif i == 9:
                Shop.UpdateOfferData(self, self.offer_index)
                ShopResponse(self.client, self.player, 0, {"id": 2}, count[ii]).send()
                self.player.tokensdoubler += count[ii]
                DataBase.replaceValue(self, 'tokensdoubler', self.player.tokensdoubler)

            elif i == 1:
                Shop.UpdateOfferData(self, self.offer_index)
                ShopResponse(self.client, self.player, 0, {"id": 7}, count[ii]).send()
                self.player.gold += count[ii]
                DataBase.replaceValue(self, 'gold', self.player.gold)

            elif i == 8:
                Shop.UpdateOfferData(self, self.offer_index)
                ShopResponse(self.client, self.player, 0, {"id": 6, "scid": brawlerID[ii]}, count[ii]).send()
                self.player.brawlers_upgradium[str(brawlerID)] += count[ii]
                DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)

            elif i == 4:
                LogicSkinDataCommand(self.client, self.player, skinID[ii]).send()
                Shop.UpdateOfferData(self, self.offer_index)
            elif i == 3:
                LogicBrawlerDataCommand(self.client, self.player, brawlerID[ii], 0).send()
                Shop.UpdateOfferData(self, self.offer_index)
            elif i == 7:
                Shop.UpdateOfferData(self, self.offer_index)
                ShopResponse(self.client, self.player, 0, {"id": 3}, count[ii]).send()
                self.player.tickets += count[ii]
                DataBase.replaceValue(self, 'tickets', self.player.tickets)
            
            else:
                OutOfSyncMessage(self.client, self.player, f'Claiming offer with type {id} is not supported yet').send()

