from Database.DatabaseManager import DataBase

from Utils.Reader import BSMessageReader

from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage


class LogicSetPlayerThumbnailCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.player.profile_icon = self.read_Vint()


    def process(self):
        if(self.player.profile_icon == 22):
            if(self.player.vip not in [4,5]):
                self.player.err_code = 1
                return LoginFailedMessage(self.client, self.player, "У вас нету привилегии MEDIA").send()
        elif(self.player.profile_icon == 20):
            if(self.player.vip not in [1,5]):
                self.player.err_code = 1
                return LoginFailedMessage(self.client, self.player, "У вас нету привилегии LITE").send()
        elif(self.player.profile_icon == 19):
            if(self.player.vip not in [2,5]):
                self.player.err_code = 1
                return LoginFailedMessage(self.client, self.player, "У вас нету привилегии VIP").send()
        elif(self.player.profile_icon == 21):
            if(self.player.vip not in [3,5]):
                self.player.err_code = 1
                return LoginFailedMessage(self.client, self.player, "У вас нету привилегии PREMIUM").send()
        
        DataBase.replaceValue(self, 'profileIcon', self.player.profile_icon)