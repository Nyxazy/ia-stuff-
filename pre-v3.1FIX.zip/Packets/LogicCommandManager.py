from Utils.Reader import BSMessageReader
from Packets.Commands.Client.LogicUpgradeBrawler import Upgrade_Brawler
from Packets.Commands.Client.LogicSetPlayerThumbnailCommand import LogicSetPlayerThumbnailCommand
from Packets.Commands.Client.LogicSetPlayerNameColorCommand import LogicSetPlayerNameColorCommand
from Packets.Commands.Client.LogicPurchaseBoxCommand import LogicPurchaseBoxCommand
from Packets.Commands.Client.LogicPurchaseOfferCommand import LogicPurchaseOfferCommand
from Packets.Commands.Client.LogicSelectSkinCommand import LogicSelectSkinCommand
from Packets.Commands.Client.LogicSetPlayerStarpowerCommand import LogicSetPlayerStarpowerCommand
from Packets.Commands.Client.LogicPurchaseHeroLvlUpMaterialCommand import LogicPurchaseHeroLvlUpMaterialCommand
from Packets.Commands.Client.LogicPurchaseDoubleCoinsCommand import LogicPurchaseDoubleCoinsCommand
from Packets.Commands.Client.LogicBuySkinCommand import LogicBuySkinCommand
from Packets.Commands.Client.LogicClaimRankUpRewardCommand import LogicClaimRankUpRewardCommand
from Packets.Commands.Client.LogicNewEventCommand import LogicNewEventCommand
from Packets.Commands.Client.LogicViewNotificationCommand import LogicViewNotificationCommand


class EndClientTurn(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player

    def decode(self):
        self.a = self.read_Vint()
        self.b = self.read_Vint()
        self.c = self.read_Vint()
        self.d = self.read_Vint()
        self.commandID = self.read_Vint()


    def process(self):
        if self.commandID == 528:
            LogicViewNotificationCommand.decode(self)
            LogicViewNotificationCommand.process(self)

        elif self.commandID == 500 or self.commandID == 535:
            LogicPurchaseBoxCommand.decode(self)
            LogicPurchaseBoxCommand.process(self)

        elif self.commandID == 517:
            LogicClaimRankUpRewardCommand.decode(self)
            LogicClaimRankUpRewardCommand.process(self)

        elif self.commandID == 519:
            LogicPurchaseOfferCommand.decode(self)
            LogicPurchaseOfferCommand.process(self)

        elif self.commandID == 503:
            LogicNewEventCommand.decode(self)
            LogicNewEventCommand.process(self)

        elif self.commandID == 505:
            LogicSetPlayerThumbnailCommand.decode(self)
            LogicSetPlayerThumbnailCommand.process(self)

        elif self.commandID == 506:
            LogicSelectSkinCommand.decode(self)
            LogicSelectSkinCommand.process(self)
            
        elif self.commandID == 507:
            LogicBuySkinCommand.decode(self)
            LogicBuySkinCommand.process(self)

        elif self.commandID == 520:
            Upgrade_Brawler.decode(self)
            Upgrade_Brawler.process(self)

        elif self.commandID == 521:
            LogicPurchaseHeroLvlUpMaterialCommand.decode(self)
            LogicPurchaseHeroLvlUpMaterialCommand.process(self)

        elif self.commandID == 509:
            LogicPurchaseDoubleCoinsCommand.decode(self)
            LogicPurchaseDoubleCoinsCommand.process(self)

        elif self.commandID == 527:
            LogicSetPlayerNameColorCommand.decode(self)
            LogicSetPlayerNameColorCommand.process(self)

        elif self.commandID == 529:
            LogicSetPlayerStarpowerCommand.decode(self)
            LogicSetPlayerStarpowerCommand.process(self)

        elif self.commandID >= 0:
            pass