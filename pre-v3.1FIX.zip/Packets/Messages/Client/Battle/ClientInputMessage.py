from Packets.Messages.Server.Battle.VisionUpdateMessage import VisionUpdateMessage

from Utils.Reader import BSMessageReader
from Utils.Helpers import Helpers
from Utils.BitStream import BitStream

class ClientInputMessage(BitStream):
	def __init__(self, client, player, initial_bytes):
		super().__init__(initial_bytes)
		self.player = player
		self.client = client


	def decode(self):
		pomet = []
		self.readPositiveInt(14)
		self.readPositiveInt(10)
		self.readPositiveInt(13)
		self.readPositiveInt(10)
		count = self.readPositiveInt(5)
		for i in range(count):
			pomet.append(self.ogo())
		print(pomet)
		
		if pomet != []:
			ponos = pomet[0]
			self.player.dudu = ponos["counter"]
			
			if ponos["id"] == 2:
				if Helpers.game1[0]['id'] == self.player.low_id:
					Helpers.game1[0]['battleX'] = ponos["x"]
					Helpers.game1[0]['battleY'] = ponos["y"]
				if Helpers.game1[1]['id'] == self.player.low_id:
					Helpers.game1[1]['battleX'] = ponos["x"]
					Helpers.game1[1]['battleY'] = ponos["y"]

	def process(self):
		VisionUpdateMessage(self.client, self.player).send()
	
	def ogo(self):
		sral = {}
		sral["counter"] = self.readPositiveInt(15)
		sral["id"] = self.readPositiveInt(4)
		sral["x"] = self.readInt(15)
		sral["y"] = self.readInt(15)
		#sral["dudu"] = self.readInt(15)
		return sral