from Utils.Reader import BSMessageReader

class AnalyticsEventMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.Type = self.read_string()
        self.Event = self.read_string()

    def process(self):
        print("Client | " + self.Type + " " + self.Event)