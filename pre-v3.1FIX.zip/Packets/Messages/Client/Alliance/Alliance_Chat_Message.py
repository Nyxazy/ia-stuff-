import json
import pymysql
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage

from Database.DatabaseManager import DataBase
from Utils.Reader import BSMessageReader
from Database.databasconnect import get_db_path
from Packets.Commands.Server.ShopResponse import ShopResponse

# Подключение к базе данных
def get_mysql_connection():
    return get_db_path(True)

class AllianceChatMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.bot_msg = ''
        self.send_ofs = False
        self.IsAcmd = False

    def decode(self):
        self.msg = self.read_string()
        self.args = self.msg.strip().split()
        self.command = self.args[0]
        
        
        if self.command == "/help":
            self.IsAcmd = True
            self.bot_msg = f"Команды:\n/help - показывает информацию об аккаунте"
        elif self.command == "/info":
            self.IsAcmd = True
            self.bot_msg = f"Имя: {self.player.name}\nКол-во трофеев: {self.player.trophies}\nvВип: {self.player.vip}\nВаш ID: {self.player.low_id}\nТокен: {self.player.token}"
        elif self.command == "/promo":
            self.filename = "JSON/promocodes.json"
            self.promocodes = self.load_promocodes()
            
            self.isAcmd = True
            promoc = self.args[1]
            if len(self.args) <= 1:
                self.bot_msg = "Промокода не существует!"
                return False

            if promoc not in self.promocodes:
                self.bot_msg = "Промокода не существует!"
                return False

            promo = self.promocodes[promoc][0]

            if self.player.low_id in promo["lowids"]:
                self.bot_msg = "Вы уже активировали этот промокод!"
                return False
            
            if promo["max_activations"] != -1 and len(promo["lowids"]) >= promo["max_activations"]:
                self.bot_msg = "Промокод достиг максимального количества активаций!"
                return False
            
            promo["lowids"].append(self.player.low_id)
            promo["max_activations"] -= 1
            self.save_promocodes()
            self.bot_msg = f"Вы активировали промокод #{promoc}!\nПолучено: {promo['give']} кристаллов.\nДля стабильной работы перезайдите на сервер"
            self.add_gems(promo['give'])



    def load_promocodes(self):
        try:
            with open(self.filename, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}
    
    def save_promocodes(self):
      with open(self.filename, 'w') as f:
        json.dump(self.promocodes, f, indent=4)


    def add_gems(self, amount):
        ShopResponse(self.client, self.player, 0, {"id": 8}, amount).send()
        self.player.gems += amount
        DataBase.replaceValue(self, 'gems', self.player.gems)
        

    def process(self):
        if self.send_ofs == False and self.IsAcmd == False:
            DataBase.Addmsg(self, self.player.club_low_id, 2, 0, self.player.low_id, self.player.name, self.player.club_role, self.msg)
            DataBase.loadClub(self, self.player.club_low_id)
            for i in self.plrids:
                AllianceChatServerMessage(self.client, self.player, self.msg, self.player.club_low_id).sendWithLowID(i)
                DataBase.DeleteAllMsg(self, self.player.club_low_id)

        if self.bot_msg != '':
            AllianceChatServerMessage(self.client, self.player, self.msg, self.player.club_low_id, True).send()
            AllianceBotChatServerMessage(self.client, self.player, self.bot_msg).send()

        if self.send_ofs:
            self.player.err_code = 1
            LoginFailedMessage(self.client, self.player, 'Всё готово! Если айди правильный, то при следующем заходе в игру будет загружен привязанный к нему аккаунт').send()