from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage

from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Utils.Reader import BSMessageReader
from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase
import time

import json

def get_ban_reason(data, user_id):
    for user in data["banned_users"]:
        if user["id"] == user_id:
            return user["reason"]
    return None

class LoginMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.high_id = self.read_int()
        self.player.low_id = self.read_int()
        self.player.token = self.read_string()
        self.major = self.read_int()
        self.minor = self.read_int()
        self.build = self.read_int()
        
        self.fingerprint_sha = self.read_string()
        self.read_int()
        OpenUDID = self.read_string()
        AndroidID = self.read_string()
        OSVersion = self.read_string()
        self.banned = json.loads(open('JSON/banned.json', 'r', encoding="utf-8").read())


    def process(self):


        if self.major != 18:
            self.player.err_code = 8
            LoginFailedMessage(self.client, self.player, "Your client is outdated, click below to download the new version!").send()

        if self.build != 104:
            self.player.err_code = 9
            LoginFailedMessage(self.client, self.player, "Вышла новая версия Echo Brawl! Скачай ее в тгк: t.me/echobrawl").send()

        reason = get_ban_reason(self.banned, self.player.low_id)
        if reason:
            self.player.err_code = 11
            LoginFailedMessage(self.client, self.player, f"Вы были заблокированы на сервере.\nПричина: {get_ban_reason(self.banned, self.player.low_id)}").send()

        if self.player.maintenance:
            LoginFailedMessage(self.client, self.player, "").send()

        if self.fingerprint_sha != self.player.patch_sha and self.player.patch:
            LoginFailedMessage(self.client, self.player, "").send()

        elif self.player.low_id != 0:
            LoginOkMessage(self.client, self.player).send()
            OwnHomeDataMessage(self.client, self.player).send()
            try:
                MyAllianceMessage(self.client, self.player, self.player.club_low_id).send()
                AllianceStreamMessage(self.client, self.player, self.player.club_low_id, 0).send()
            except:
                MyAllianceMessage(self.client, self.player, 0).send()
                AllianceStreamMessage(self.client, self.player, 0, 0).send()

            if self.player.room_id > 0:
                TeamGameroomDataMessage(self.client, self.player).send()
            
        else:
            self.player.low_id = Helpers.randomID(self)
            self.player.high_id = 0
            self.player.token = Helpers.randomStringDigits(self)

            LoginOkMessage(self.client, self.player).send()
            #DataBase.DeleteTrash(self)
            DataBase.createAccount(self)
            #DataBase.fixAccount(self)
            OwnHomeDataMessage(self.client, self.player).send()
            MyAllianceMessage(self.client, self.player, 0).send()
            AllianceStreamMessage(self.client, self.player, 0, 0).send()