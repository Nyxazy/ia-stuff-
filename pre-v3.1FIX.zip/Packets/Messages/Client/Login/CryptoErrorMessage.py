from Packets.Messages.Server.Login.CryptoError import CryptoError
from Utils.Reader import BSMessageReader


class CryptoErrorMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.CryptoError = self.read_int()

    def process(self):
        CryptoError(self.client, self.player, self.CryptoError).send()