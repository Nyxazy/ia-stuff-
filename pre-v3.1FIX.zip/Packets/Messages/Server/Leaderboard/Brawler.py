from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import sqlite3 as sql
import json
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage

class BrawlerLeader(Writer):

    def __init__(self, client, player, ID):
        super().__init__(client)
        self.id = 24403
        self.player = player
        self.conn = sql.connect("Database/leaders.db")
        self.cursor = self.conn.cursor()
        self.brawler = ID
        
    def by_tr(self,plr):
        return plr[2]['brawlersTrophies'][str(self.brawler)]
    	
    def encode(self):
        self.player.err_code = 1
        return LoginFailedMessage(self.client, self.player, "спаркли зафикси!!!").send()
        """self.indexOfPlayer = 1
        self.writeVint(0)
        self.writeVint(0)
        self.writeScId(16,self.brawler)
        self.writeString("RU")
        matches = DataBase.GetLeaderboardByBrawler(self, self.brawler)
        list(matches).sort(key=self.by_tr, reverse=True)
        x=1
        y = 0
        self.writeVint(len(matches))
        for i in fetch:
            	
            	self.writeVint(0) # High ID
            	self.writeVint(i[0]) # Low ID
            	print(i)
            	self.writeVint(1)
            	self.writeVint(i[2]['brawlersTrophies'][str(self.brawler)]) # Player Trophies
            	self.writeVint(1)
            	self.writeString()
            	
            	self.writeString(i[1])# Player Name
            	self.writeVint(9999) # Player Level
            	self.writeVint(28000000 + i[3])
            	self.writeVint(43000000 + i[4])
            	self.writeVint(0) # Unknown


        self.writeVint(0)
        self.writeVint(1)
        self.writeVint(0)
        self.writeVint(0) # Leaderboard global TID
        self.writeString("RU")"""