from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class GetLeaderboardGlobalOkMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24403
        self.player = player

    def encode(self):
        self.indexOfPlayer = 1
        self.writeVint(1)
        self.writeVint(0) # SCID
        self.writeString()

        fetch = DataBase.getLeaders(self)
        x=1
        self.writeVint(len(fetch)) # Players Count

        for i in fetch:
            if i[0] == self.player.low_id:
                x = fetch.index(i) + 1
            self.writeVint(0) # High ID
            self.writeVint(i[0]) # Low ID

            self.writeVint(1)
            self.writeVint(i[2]) # Player Trophies

            self.writeVint(1)

            if i[7] != "none":
                titul = i[7]
            else:
                titul = ""

            if i[5] != 0:
                self.writeString(DataBase.loadClubName(self, i[5]))


            else:
                self.writeString()
            
            self.writeString(f"{self.player.prefixs[i[6]]}{i[1]} {titul}") # Player Name

            self.writeVint(1) # Player Level
            self.writeVint(28000000 + i[3])
            self.writeVint(43000000 + i[4])
            self.writeVint(0)


        self.writeVint(0)
        self.writeVint(x)
        self.writeVint(1)
        self.writeVint(0) # Leaderboard global TID
        self.writeString("RU")