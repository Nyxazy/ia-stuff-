from Utils.Writer import Writer
from datetime import datetime
import random

class LobbyInfoMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23457
        self.player = player
    def encode(self):
        now = datetime.now()
        ping = random.randint(19,180)
        if ping <= 30: ping1 = "▂"
        elif ping >= 31 and ping <= 75: ping1 = "▄"
        elif ping >= 76 and ping <= 130: ping1 = "▅"
        elif ping >= 131: ping1 = "▆"
        self.writeVint(0)#
        n = "                                                                                                                                                                                                                                 "
        self.writeString(f'\n\n\n{n}Echo Brawl\n{n}Version:  Dev\n{n}Telegram:  t.me/echobrawl\n{n}eID:  {self.player.low_id}\n{n}Online:  {0}\n{n}Ping:  {ping1}  ({ping})\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n')
        self.writeVint(1)