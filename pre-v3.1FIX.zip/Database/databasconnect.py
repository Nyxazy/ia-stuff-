import pymysql

def get_db_path(test=False):
    host = "127.127.126.26"
    user = "root"
    password = ""
    database = "test"
    if test == True:
      return pymysql.connect(
    host=(host),
    user=(user),
    password=(password),
    database=(database),
    cursorclass=pymysql.cursors.DictCursor) 
    else:
      return pymysql.connect(
    host=(host),
    user=(user),
    password=(password),
    database=(database))
  
   

def get_club_id(low_id):
 return