import json
import datetime
from Utils.EventGenerator import EventGenerator
from Database.databasconnect import get_db_path
import pymysql
from Utils.OfferGenerator import OfferGenerator

SHOP_FILE = "JSON/offers.json"
LOG_FILE = "admin_log.txt"
BANNED_FILE = "JSON/banned.json"


def load_data(file_path):
    try:
        with open(file_path, 'r', encoding='UTF-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}  

def save_data(file_path, data):
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
        
def log_action(action, details=""):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {action}: {details}\n")

def ban_user():
    user_id = input("Введите ID пользователя для бана: ")
    reason = input("Введите причину бана: ")

    banned_data = load_data(BANNED_FILE)
    banned_users = banned_data.get("banned_users", [])
    
    for banned in banned_users:
      if str(banned.get("id")) == user_id:
        print("Пользователь уже забанен.")
        return

    new_ban = {"id": int(user_id), "reason": reason}
    banned_users.append(new_ban)
    banned_data["banned_users"] = banned_users
    save_data(BANNED_FILE, banned_data)


    log_action("Ban User", f"User ID: {user_id}, Reason: {reason}")
    print(f"Пользователь с ID {user_id} забанен. Причина: {reason}")

def create_promotion():
    shop_data = load_data(SHOP_FILE)
    
    next_id = 0
    if shop_data:
        next_id = max(int(k) for k in shop_data.keys()) + 1
        
    print("Введите данные для акции:")
    try:
      promotion_id = int(input("ID: "))
      offer_title = input("Название акции:: ")
      cost = int(input("Цена: "))
      old_cost = int(input("OldCost: "))
      multiplier = int(input("Multiplier: "))
      brawler_id = int(input("BrawlerID: "))
      skin_id = int(input("SkinID: "))
      shop_type = int(input("ShopType: "))
      shop_display = int(input("ShopDisplay: "))
    except ValueError:
      print("Ошибка: Пожалуйста, введите целые числа для числовых полей.")
      return

    new_promotion = {
        "ID": [promotion_id,0,0],
        "OfferTitle": offer_title,
        "Cost": cost,
        "OldCost": old_cost,
        "Multiplier": [multiplier,0,0],
        "BrawlerID": [brawler_id,0,0],
        "SkinID": [skin_id,0,0],
        "WhoBuyed": [],
        "ShopType": shop_type,
        "ShopDisplay": shop_display
    }

    shop_data[str(next_id)] = new_promotion
    save_data(SHOP_FILE, shop_data)
    log_action("Create Promotion", f"New Promotion ID: {next_id}, Title: {offer_title}")

    print(f"Акция с ID {next_id} добавлена в {SHOP_FILE}")

def update_events():
    print("\n\nуспешно!")
    a = EventGenerator()
    a.generateEvents() 
    log_action("Update Events", "Update events function called")

def update_shop():
    print("\n\nуспешно!")
    a = OfferGenerator()
    a.updateOffers() 
    log_action("Update Shop", "Update shop function called")

def give_vip():
    conn = get_db_path()
    with conn:    
        cur = conn.cursor()
        try:
            low_id = int(input("lowID: "))
            viplevel = int(input("Привилегия (ID): "))
        except ValueError:
            print("Ошибка: Пожалуйста, введите целые числа для числовых полей.")
            return
        cur.execute(f'UPDATE players SET vip = {viplevel} WHERE lowID = {low_id}')
        conn.commit()
        cur.close()
        print("Выдано!")
        log_action("Give vip", f"gived vip for player {low_id} (VIP: {viplevel})")

def give_titul():
    conn = get_db_path()
    with conn:    
        cur = conn.cursor()
        try:
            low_id = int(input("lowID: "))
            titul = input("Титул: ")
        except ValueError:
            print("Ошибка: Пожалуйста, введите целые числа для числовых полей.")
            return
        cur.execute(f"UPDATE players SET titul = '{titul}' WHERE lowID = {low_id}")
        conn.commit()
        cur.close()
        print("Выдано!")
        log_action("Give titul", f"gived titul for player {low_id} (ТИТУЛ: {titul})")

def give_gems_notif():
    conn = get_db_path()
    with conn:    
        cur = conn.cursor()
        try:
            low_id = int(input("lowID: "))
            gems = int(input("Кол-во гемов: "))
        except ValueError:
            print("Ошибка: Пожалуйста, введите целые числа для числовых полей.")
            return
        cur.execute(f"UPDATE players SET Notifications = 'yes' WHERE lowID = {low_id}")
        cur.execute(f'UPDATE players SET notifgems = {gems} WHERE lowID = {low_id}')
        conn.commit()
        cur.close()
        print("Выдано!")
        log_action("Give gems", f"gived gems for player {low_id} ({gems})")

def process_player_trophies():
    connection = None
    try:
        # Устанавливаем соединение с БД
        connection = get_db_path(True)

        with connection.cursor() as cursor:
            cursor.execute("SELECT id, trophies, brawlersTrophies, brawlersTrophiesForRank, tickets FROM players")
            players = cursor.fetchall()

            for player in players:
                player_id = player['id']
                t = player['tickets']
                current_trophies = player['trophies']
                brawlers_trophies = json.loads(player['brawlersTrophies']) if player['brawlersTrophies'] else {}
                brawlers_trophies_for_rank = json.loads(player['brawlersTrophiesForRank']) if player['brawlersTrophiesForRank'] else {}

                updated_brawlers_trophies = False
                updated_brawlers_trophies_for_rank = False
                total_trophies_reduction = 0

                for brawler_id in range(27):
                   if str(brawler_id) in brawlers_trophies and brawlers_trophies[str(brawler_id)] > 500:
                        trophy_reduction = brawlers_trophies[str(brawler_id)] - 500
                        total_trophies_reduction += trophy_reduction
                        brawlers_trophies[str(brawler_id)] = 500
                        updated_brawlers_trophies = True

                for brawler_id in range(27):
                    if str(brawler_id) in brawlers_trophies_for_rank and brawlers_trophies_for_rank[str(brawler_id)] > 500:
                         
                         brawlers_trophies_for_rank[str(brawler_id)] = 500
                         updated_brawlers_trophies_for_rank = True

                # Обновляем базу данных, если были изменения
                if updated_brawlers_trophies or updated_brawlers_trophies_for_rank:

                    if updated_brawlers_trophies:
                        updated_brawlers_trophies_json = json.dumps(brawlers_trophies)
                    else:
                         updated_brawlers_trophies_json = player['brawlersTrophies']

                    if updated_brawlers_trophies_for_rank:
                        updated_brawlers_trophies_for_rank_json = json.dumps(brawlers_trophies_for_rank)
                    else:
                         updated_brawlers_trophies_for_rank_json = player['brawlersTrophiesForRank']


                    updated_trophies = current_trophies - total_trophies_reduction

                    kupons = int(total_trophies_reduction / 10)

                    kupons = kupons + t

                    sql = "UPDATE players SET brawlersTrophies = %s, brawlersTrophiesForRank = %s, trophies = %s, highest_trophies = %s, tickets = %s WHERE id = %s"
                    cursor.execute(sql, (updated_brawlers_trophies_json, updated_brawlers_trophies_for_rank_json, updated_trophies, updated_trophies, kupons, player_id))


                    connection.commit()
                    print(f"Игрок {player_id} обновлен, вычтено {total_trophies_reduction} кубков.")
    except Exception as e:
        print(f"Произошла ошибка: {e}")
    finally:
        if connection:
            connection.close()

def main_menu():
    while True:
        print("\n--- Меню ---")
        print("1. Забанить пользователя")
        print("2. Создать акцию")
        print("3. Обновить события")
        print("4. Выдать привилегию пользователю")
        print("5. Обновить магазин (хз зчаем но ладн)")
        print("6. Выдать титул пользователю (none - значит не будет)")
        print("7. Выдать гемы через нотиф")
        print("8. Сделать сброс сезона xd")
        print("100. Выход")

        choice = input("Выберите действие: ")

        if choice == "1":
            ban_user()
        elif choice == "2":
            create_promotion()
        elif choice == "3":
            update_events()
        elif choice == "4":
            give_vip()
        elif choice == "5":
            update_shop()
        elif choice == "6":
            give_titul()
        elif choice == "7":
            give_gems_notif()
        elif choice == "8":
            process_player_trophies()
        elif choice == "100":
            print("Выход из утилиты.")
            break
        else:
            print("Неверный выбор. Пожалуйста, выберите действие из меню.")

if __name__ == "__main__":
    main_menu()